var date = new Date();
var day = date.getDate() + 1;
var month = date.getMonth() + 1 ;
if(day >= 32) { day = day - 1 }
$(".row").countdown("2022/" + month + "/" + day, function(event) {
$('.second').text(event.strftime('%H'));
$('.third').text(event.strftime('%M'));
$('.four').text(event.strftime('%S'));
});