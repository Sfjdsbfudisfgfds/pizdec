<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/engine/classes/Main.class.php';

$Engine = new Engine;
function message($data,$err = false){
    return json_encode(array(
        'error' => $err,
        'data' => $data
    ));
}
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/engine/ajax/' . $_GET['type'] . '.php')) {
    $type = $_GET['get'];
    include($_SERVER['DOCUMENT_ROOT'] . '/engine/ajax/' . $_GET['type'] . '.php');
} elseif($_REQUEST['nick'] && $_REQUEST['srv']) die($Engine->buy_price($_REQUEST['nick'],$_REQUEST['group'],$_REQUEST['promo'],$_REQUEST['srv_id'],$_REQUEST['vk_id'], "check"));
else
    die("UNKNOW AJAX");