<?php

$config = array(
    'db' => array(
        'db_host'     => 'sql302.unaux.com', //IP дедика, на котором стоит сайт
        'db_user'     => 'unaux_30763493', //Юзер
        'db_pass'     => 'kpmhrhf7kz8', //Пароль
        'db_name'     => 'unaux_30763493_icehost', //Название базы данных
    ),


    'server' => array(
        'ip' => 'play.bestcraft.xyz', //IP сервера
        'name' => 'BestCraft', //Название сервера
        'design_name' => '<span style="color: orange;">Best</span><span style="color: yellow;">Craft</span>', //Название сервера в цвете
    ),

    'freekassa' => array( // Настройки FreeKassa
        'project_id' => '', // ID(Номер) проекта
        'key' => '', // Секретный ключ
    ),
);