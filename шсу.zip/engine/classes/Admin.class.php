<?php
include 'Main.class.php';
class Admin
{

    public function __construct()
    {
        $this->engine = new Engine;
    }

    public function all_promo()
    {

        $query = $this->engine->query("SELECT * FROM `promo`");
        while ($q = $query->fetch_object()) {
            $return .= '<li class="list-group-item">
                           <p style="font-size: 20px;">
                              Промокод: ' . $q->name . ' 
                              <a href="/admin/?action=promo&type=edit&id=' . $q->id . '"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                              <a href="/admin/?action=promo&type=remove&id=' . $q->id . '"><i class="fa fa-times" aria-hidden="true"></i></a>
                           </p>
                           <span class="label label-success">Скидка: ' . $q->disc . '%</span>
                        </li>';
        }
        return $return;
    }

    public function all_groups($server)
    {
        $query = $this->engine->query("SELECT * FROM `groups` WHERE `server` = '".(int)$server."'");
        while ($q = $query->fetch_object()) {
            if ($q->surcharge == 1)
                $s = '<span class="label label-success">С доплатой</span>';
            else
                $s = '<span class="label label-warning">Без доплаты</span>';

            $return .= '<li class="list-group-item">
                           <p style="font-size: 20px;">
                              ' . $q->name . '
                              <a href="/admin/?action=groups&type=edit&id=' . $q->id . '"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                              <a href="/admin/?action=groups&type=remove&id=' . $q->id . '"><i class="fa fa-times" aria-hidden="true"></i></a>
                           </p>
						   <span class="label label-warning">' . $q->price . ' РУБ</span>
						   ' . $s . '
						   ' . $c . '
						   <span class="label label-danger">' . $q->category . '</span>
                           <br><br><kbd style="background-color: #000000">' . $q->cmd . '</kbd>
                        </li>';
        }
        return $return;
    }

    public function all_servers()
    {

        $query = $this->engine->query("SELECT * FROM `servers`");
        while ($q = $query->fetch_object()) {
            $return .= '<li class="list-group-item">
                           <p style="font-size: 20px;">
                              Сервер: ' . $q->name . ' 
                              <a href="/admin/?action=server&type=edit&id=' . $q->id . '"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                              <a href="/admin/?action=server&type=remove&id=' . $q->id . '"><i class="fa fa-times" aria-hidden="true"></i></a>
                           </p>
                        </li>';
        }
        return $return;
    }

    public function all_extradition()
    {

        $query = $this->engine->query("SELECT * FROM `extradition`");
        while ($q = $query->fetch_object()) {
            $return .= '<li class="list-group-item">
                           <p style="font-size: 20px;">
                              Сервер: ' . $q->name . ' 
                              <a href="/admin/?action=extradition&type=edit&id=' . $q->id . '"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                              <a href="/admin/?action=extradition&type=remove&id=' . $q->id . '"><i class="fa fa-times" aria-hidden="true"></i></a>
                           </p>
                           <span class="label label-success">' . $q->ip . ':' . $q->port . '</span>
                        </li>';
        }
        return $return;
    }

    public function all_extradition_text()
    {

        $query = $this->engine->query("SELECT * FROM `extradition`");
        while ($q = $query->fetch_object()) {
            $return .= '<a href="/console/?action=console&type=govno&id=' . $q->id . '" style="font-size: 20px; text-decoration: none; color:black">
                              Сервер: ' . $q->name . ' <br /><br />
                           </a>';
        }
        return $return;
    }

    public function all_servers_groups()
    {

        $query = $this->engine->query("SELECT * FROM `servers`");
        while ($q = $query->fetch_object()) {
            if ($q->status == 1)
                $s = '<span class="label label-success">Активирован</span>';
            else
                $s = '<span class="label label-warning">Не активирован</span>';
            $return .= '<li class="list-group-item">
                           <p style="font-size: 20px;">
                              Сервер: ' . $q->name . ' 
                           </p>
                           '.$s.'<br><br>
                              <a href="/admin/?groups=' . $q->id . '" class="btn btn-primary btn-xs btn-block">Перейти к группам</a>
                        </li>';
        }
        return $return;
    }

    public function all_donaters()
    {

        $query = $this->engine->query("SELECT * FROM `orders` WHERE status = 1 ORDER BY `id` DESC");
        while ($q = $query->fetch_object()) {
            $return .= '<tr>
                <td>
                    ' . $q->id . '
                </td>
                <td><b>'.$q->nick.'</b> 
                    [' . $this->engine->date($q->date . " " . $q->time) . ']</td>
                <td>
                    ' . $q->group . '
                </td>
                <td><span class="badge bg-green">' . $q->price . ' РУБ</span></td>
            </tr>';
        }
        return $return;
    }

    public function alert($text, $action)
    {
        return '<div class="alert alert-dismissible alert-' . $action . '">
				  <p>' . $text . '</p>
				</div>';
    }

	/* GROUP */

    public function group($id)
    {
        $group = $this->engine->query_result("SELECT * FROM groups WHERE id = ".(int)$id." LIMIT 1");
		if(!$group) return false;
		return $group;
    }

    public function remove_group($id)
    {
        $this->engine->query("DELETE FROM `groups` WHERE `id` = ".(int)$id);
    }

    public function add_group($group)
    {
        if(!$group['name'] || !$group['price'] || !$group['cmd'] || !$group['category'] || !$group['server']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("INSERT INTO `groups` (`name`, `price`, `surcharge`, `cmd`, `category`, `server`) VALUES ('".$group['name']."', '".$group['price']."', '".$group['surcharge']."', '".$group['cmd']."', '".$group['category']."', '".$group['server']."')");

		return $this->alert("Группа успешно добавлена!", "success");
    }

    public function update_group($group, $id)
    {
        if(!$group['name'] || !$group['price'] || !$group['cmd'] || !$group['category'] || !$group['server']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("UPDATE `groups` SET `name`='".$group['name']."',`price`='".$group['price']."',`surcharge`='".$group['surcharge']."',`cmd`='".$group['cmd']."',`category`='".$group['category']."',`server`='".$group['server']."' WHERE id = ".(int)$id);

		return $this->alert("Группа успешно обновлена!", "success");
    }

    /* SERVERS */

    public function server($id)
    {
        $server = $this->engine->query_result("SELECT * FROM servers WHERE id = ".(int)$id." LIMIT 1");
		if(!$server) return false;
		return $server;
    }

    public function remove_server($id)
    {
        $this->engine->query("DELETE FROM `servers` WHERE `id` = ".(int)$id);
    }

    public function add_server($server)
    {
        if(!$server['name']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("INSERT INTO `servers`(`name`, `status`) VALUES ('{$server['name']}', '{$server['status']}')");

		return $this->alert("Сервер успешно добавлен!", "success");
    }

    public function update_server($server, $id)
    {
        if(!$server['name']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("UPDATE `servers` SET `name`='{$server['name']}', `status`='{$server['status']}' WHERE id = ".(int)$id);

		return $this->alert("Сервер успешно обновлен!", "success");
    }

    /* EXTRA_SERVERS */

    public function extra($id)
    {
        $server = $this->engine->query_result("SELECT * FROM extradition WHERE id = ".(int)$id." LIMIT 1");
		if(!$server) return false;
		return $server;
    }

    public function remove_extra($id)
    {
        $this->engine->query("DELETE FROM `extradition` WHERE `id` = ".(int)$id);
    }

    public function add_extra($server)
    {
        if(!$server['name'] || !$server['ip'] || !$server['port'] || !$server['pass']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("INSERT INTO `extradition`(`ip`, `port`, `pass`, `name`, `server`) VALUES ('{$server['ip']}', '{$server['port']}', '{$server['pass']}', '{$server['name']}', '{$server['server']}')");

		return $this->alert("Сервер успешно добавлен!", "success");
    }

    public function update_extra($server, $id)
    {
        if(!$server['name'] || !$server['ip'] || !$server['port'] || !$server['pass']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("UPDATE `extradition` SET `ip`='{$server['ip']}', `port`='{$server['port']}', `pass`='{$server['pass']}', `name`='{$server['name']}', `server`='{$server['server']}' WHERE id = ".(int)$id);

		return $this->alert("Сервер успешно обновлен!", "success");
    }

    /* PROMO */

    public function promo($id)
    {
        $promo = $this->engine->query_result("SELECT * FROM promo WHERE id = ".(int)$id." LIMIT 1");
		if(!$promo) return false;
		return $promo;
    }

    public function remove_promo($id)
    {
        $this->engine->query("DELETE FROM `promo` WHERE `id` = ".(int)$id);
    }

    public function add_promo($promo)
    {
        if(!$promo['name'] || !$promo['disc']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("INSERT INTO `promo`(`name`, `disc`) VALUES ('{$promo['name']}', '{$promo['disc']}')");

		return $this->alert("Промокод успешно добавлен!", "success");
    }

    public function update_promo($promo, $id)
    {
        if(!$promo['name'] || !$promo['disc']) return $this->alert("Необходимо заполнить все поля!", "danger");

		$this->engine->query("UPDATE `promo` SET `name`='".$promo['name']."',`disc`='".$promo['disc']."' WHERE id = ".(int)$id);

		return $this->alert("Промокод успешно обновлен!", "success");
    }

}
?>
