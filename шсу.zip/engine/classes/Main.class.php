﻿<?php
date_default_timezone_set('Europe/Moscow');
class Engine{

	public $db;
	public $cfg;
	public $messages = array();

	public function __construct(){
		require_once($_SERVER['DOCUMENT_ROOT'].'/engine/config.php');
		$this->cfg = $config;
		$this->db = new mysqli($config['db']['db_host'], $config['db']['db_user'], $config['db']['db_pass'], $config['db']['db_name']);
		if($this->db->connect_error){
			die("Couldn't connect to MySQLi: ".$this->db->connect_error);
		}
		if (!$this->db->set_charset("utf8")) {
			die("Ошибка при загрузке набора символов utf8: ".$this->db->error);
		}
		$this->events();
	}

	private function events(){
		if(isset($_POST['buy'])) {
			$buy = explode("|", $this->buy_price($_POST['nickname'], $_POST['group'], $_POST['promo'], $_POST['srv_id'], $_POST['vk_id'], "buy"));
			if($buy[0] == "error") return $this->add_message($buy[3],true);
			return $this->add_message('Переходим к оплате...!');
		}
		if(isset($_REQUEST['success'])) $this->add_message('Вы успешно купили привилегию!');
		if(isset($_REQUEST['error'])) $this->add_message('Во время покупки привилегии произошла ошибка!',true);
	}
	private function add_message($text,$err = false){
		$this->messages[] = array('text'=>$text, 'err'=> $err);
	}

	public function query($query){
		return $this->db->query($query);
	}

	public function query_result($query){
		return $this->db->query($query)->fetch_object();
	}

	public function escape($str){
		return $this->db->real_escape_string($str);
	}

	public function redirect($url){
		echo '<script type="text/javascript">';
		echo 'window.location.href="'.$url.'";';
		echo '</script>';
	}

	public function get_servers() {
		$i = 0;
		foreach($this->query("SELECT * FROM `servers` WHERE `status` = 1") as $s) {
			$i++;
			if($i == 1) $active = "nav-link active"; else $active = "nav-link";
			$form .= '<li class="nav-item" role="presentation"><a style="color: white"  href="#tab'.$s['id'].'" class="'.$active.'" role="tab" data-toggle="tab">'.$s['name'].'</a></li>';
		}
		return $form;
	}

	public function get_form() {
		$i = 0;
		foreach($this->query("SELECT * FROM `servers` WHERE `status` = 1") as $s) {
			$i++;
			if($i == 1) $active = "active"; else $active = '';

			$form .= '<div role="tabpanel" class="tab-pane '.$active .'" id="tab'.$s['id'].'">';
			$form .= '<form action="/" method="post" id="phpmc">';
			$form .= '<input type="hidden" name="srv_id" class="input-srv_id"  value="'.$s['id'].'">';
			$form .= $this->alert("Вы выбрали сервер: ".$s['name'], "info");
			$form .= '<div class="form-group has-feedback">';
			$form .= '<label for="nick" class="control-label">Введите ваш ник:</label>';
			$form .= '<input type="text" class="input-nick form-control" name="nickname" id="nickname" placeholder="Введите ник">';
			$form .= '</div>';
			$form .= '<div class="form-group">';
			$form .= '<label for="group" class="control-label">Выберите товар:</label>';
			$form .= '<select id="group" name="group" class="select-group form-control">';
			$form .= $this->groups($s['id']);
			$form .= '</select>';
			$form .= '</div>';
			$form .= '<input type="text" name="promo" class="input-promo form-control" id="promo" placeholder="Введите промо-код (если есть)"><br>';
			$form .= '<button type="submit" name="buy" id="buy" class="submit buy_btn btn btn-success btn-block" disabled>Введите ник и выберите привилегию</button>';
			$form .= '</form>';
			$form .= '</div>';
		}
		return $form;
	}

	public function groups($server){
		$groups = $this->query("SELECT * FROM `groups` WHERE `server` = ".(int)$server." ORDER BY `id` ASC");
		$list = array();
		while($el = mysqli_fetch_assoc($groups)) {
			if(!is_array($list[$el['category']])) $list[$el['category']] = array();
			$list[$el['category']][] = $el;
		}
		$form = '<option selected disabled>Выберите товар</option>';
		foreach($list as $cat=>$group){
			$form .= '<optgroup label="'.$cat.'">';
			foreach($group as $data){
				$form .= '<option data-price="'.$data['price'] .'" data-id="'.$data['id'] .'" value="'.$data['id'].'">'.$data['name'].' ➛ '.$data['price'] .' рублей</option>';
			}
			$form .= '</optgroup>';
		}
		return $form;
	}

	public function group($id){
		$query = $this->query_result("SELECT * FROM `groups` WHERE `id` = ".(int)$id." LIMIT 1");
		if($query == null) return false;
		return $query;
	}

	public function rcon_log($login, $cmd){
		$this->query("INSERT INTO `log` (`nick`, `message`) VALUES ('".$login."', '".$cmd."')");
	}

    public function surcharge($nick, $type = 'get', $price = '', $srv = ''){
        if($type == "get")
        {
            $replay = $this->query_result("SELECT * FROM surcharge WHERE nick = '" . $nick . "' ORDER BY id DESC LIMIT 1");
            if($replay == null) return false;
            return $replay;
        }
        elseif($type == "add") $this->query("INSERT INTO `surcharge`(`nick`, `price`, `server`) VALUES ('".$nick."', '".$price."', '".$srv."')");
	}

	public function promo($promo, $price){
		$promo = $this->escape(trim ( strip_tags ( $promo)));
		$price = (int)$price;
		$promo = $this->query_result("SELECT * FROM promo WHERE name = '{$promo}' LIMIT 1");
		if(!$promo) return $price;
		return $price - ceil(($price/100*$promo->disc));
	}

	public function buy_price($nick, $group, $promo = '', $server, $vk = '', $type = 'check'){
		$nick = $this->escape(trim ( strip_tags ( $nick)));
		$group = $this->escape(trim ( strip_tags ( $group)));
		$promo = $this->escape(trim ( strip_tags ( $promo)));
		$server = (int)$server;
		$vk = (int)$vk;

		if(empty($nick)) return "error|Ник не указан||Ник не указан";
		if(empty($group)) return "error|Купить / Доплатить||Группа не выбрана";
		$group = $this->group($group);
		if(!$group) return "error|Купить / Доплатить||Группа не обнаружена";
		$price = $group->price;
		$surcharge = $this->surcharge($nick);

		if ($group->surcharge == 1 && $surcharge->server == $server) {
			if ($surcharge != NULL) {
				$price = $price - $surcharge->price;
			}
		}

		if(!empty($promo)) $price = $this->promo($this->escape(trim(strip_tags($promo))), $price);

		if ($price > 0) {
			if($type == "check")
			{
				if ($surcharge == NULL || $group->surcharge == 0)
					return "ok|Купить за " . $price . " рублей|" . $this->alert("Вы собираетесь приобрести донат <b>{$group->name}</b> за <b>{$price}</b> рублей", "info")."|".$group->console;
				else
					return "ok|Доплатить за " . $price . " рублей|" . $this->alert("Вы собираетесь доплатить до доната <b>{$group->name}</b> за <b>{$price}</b> рублей", "info")."|".$group->console;
			}
			elseif($type == "buy") $this->buy($nick, $price, $group->id, $server);
			else return false;
		} else
			return "error|У вас имеется более высокий донат!|" . $this->alert("У вас уже имеется более высокий донат, выберите другой из списка!", "danger")."|У вас имеется более высокий донат!";
	}


	/* НАЧИНАТЬ ОТСЮДА */

	public function buy($nick, $price, $group, $server){
		$date = date("Y-m-d");
		$time = date("G:i:s");
		$month = date("n");
		$group = $this->group($group);
		$this->query("INSERT INTO `orders`(`groupid`, `group`, `price`, `nick`, `date`, `time`, `month`, `server`) VALUES ('".$group->id."','".$group->name."','".$price."','".$nick."', '".$date."', '".$time."', '".$month."', '".$server."')");

		$desc = "Donation";
        $sign = md5($this->cfg['freekassa']['project_id'].':'.$price.':'.$this->cfg['freekassa']['key'].':'.$desc);
        $this->redirect("https://www.free-kassa.ru/merchant/cash.php?m={$this->cfg['freekassa']['project_id']}&oa={$price}&o={$desc}&s={$sign}&us_account={$this->db->insert_id}&us_nick={$nick}&us_groupid={$group->id}&us_serverid={$server}");
	}

    public function up_json_reply($type = "error") {
        if ($type == 'error') $return = 'NO';
        else $return = 'YES';
        return $return;
    }

    public function payment_action($id, $price, $nick, $groupid, $serverid){

        $id = (int)$id;
        $price = (int)$price;
        $groupid = (int)$groupid;
        $serverid = (int)$serverid;
        $return = false;

        if($id > 0 && $price > 0)
        {
            $this->query("UPDATE `orders` SET `status` = '1' WHERE `id` = ".$id);
            $this->query("INSERT INTO `surcharge`(`nick`, `price`, `server`) VALUES ('".$nick."', '".$price."', '".$serverid."')");
            $this->payment_rcon($nick, $groupid);
            $return = true;
        }
        return $return;
    }


    public function payment_rcon($nick, $groupid){
        $group = $this->group($groupid);
        $arr = array("&lowbar;" => "_", " " => "");
        $nick = strtr($nick, $arr);
        require_once($_SERVER['DOCUMENT_ROOT'].'/engine/classes/Rcon.class.php');
        $servers = $this->query("SELECT * FROM `extradition` WHERE `server` = '{$group->server}'");
        while($s = $servers->fetch_object()){
            $rcon = new Rcon($s->ip, $s->port, $s->pass, 5);
            foreach (explode(';', $group->cmd) as $c) {
                $cmd = str_replace(array('[nick]'),array($nick), $c);
                if(@$rcon->connect()){
                    $rcon->send_command($cmd);
                    $this->rcon_log($nick, "CONNECT: ".$rcon->get_response());
                } else $this->rcon_log($nick, "ERROR: ".$rcon->get_response());
            }
        }
    }

    public function up_sign($reply, $check = false) {
        $real_sign = md5($this->cfg['freekassa']['project_id'].':'.$reply['AMOUNT'].':'.$this->cfg['freekassa']['key'].':'.$reply['MERCHANT_ORDER_ID']);
        $sign = $reply['SIGN'];
        $return = ($real_sign != $sign) ? "error" : "success";
        if ( $return == "success" ) {
            $return = $this->payment_action($reply['us_account'], $reply['AMOUNT'], $reply['us_nick'], $reply['us_groupid'], $reply['us_serverid']);
        }
        return $this->up_json_reply($return);
    }

	/* НЕ ЛЕЗЬ СЮДА ДЕБИЛ БЛЯТЬ */

	public function date($date){
		$time = explode(" ", $date);
		$month = explode("-", $time[0]);
		if($month[1] == 1) $month_t = "января";
		elseif($month[1] == 2) $month_t = "Февраля";
		elseif($month[1] == 3) $month_t = "марта";
		elseif($month[1] == 4) $month_t = "апреля";
		elseif($month[1] == 5) $month_t = "мая";
		elseif($month[1] == 6) $month_t = "июня";
		elseif($month[1] == 7) $month_t = "июля";
		elseif($month[1] == 8) $month_t = "августа";
		elseif($month[1] == 9) $month_t = "сентября";
		elseif($month[1] == 10) $month_t = "октября";
		elseif($month[1] == 11) $month_t = "ноября";
		elseif($month[1] == 12) $month_t = "декабря";
		else return $date;
		$sec = explode(":", $time[1]);
		if($time[0] == date("Y-m-d")) return "Сегодня в ".$sec[0].":".$sec[1];
		elseif($time[0] == date('Y-m-d', strtotime('-1 days'))) return "Вчера в ".$sec[0].":".$sec[1];
		else return $month[2]." ".$month_t." в ".$sec[0].":".$sec[1];
	}

	public function alert($text, $action){
		return '<div class="alert alert-dismissible alert-' . $action . '">
				  ' . $text . '
				</div>';
	}

	public function online($type = "online"){
		require_once($_SERVER['DOCUMENT_ROOT'].'/engine/classes/MCQuery.class.php');
		$mon = mcraftQuery_SE($this->cfg['server']['ip']);
		if(!$mon) return "0";
		if($type == "slots") return $mon['maxplayers'];
		else return $mon['numplayers'];
	}
}
?>