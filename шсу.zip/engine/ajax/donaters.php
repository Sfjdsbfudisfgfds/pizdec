<script>
   $(document).ready(function(){
   				$('[data-toggle="tooltip"]').tooltip({html:true}); 
   			});
</script>
<style>
	.lastBought {
	   display: inline-block;
	   width: 110px;
	   height: 110px;
	   margin-left: 15px;
	}
	div.lastBoughts .lastBought:first-child {
	   margin-left: 0px;
	}
</style>
<div class="col-md-12">
      <?php foreach($Engine->query("SELECT * FROM `orders` WHERE `status` = 1 ORDER BY `id` DESC LIMIT 8") as $u) { ?>
      <div class="lastBought">
         <img src="/engine/face.php?u=<?=$u['nick']?>&s=80&v=front" class="center-block img-circle img-responsive" data-placement="bottom" data-toggle="tooltip" type="button" title="" data-original-title="Игрок: <?=$u['nick']?><br>Купил: <font color='#9efe08'><?=$u['group']?></font><br>Время: <?=$Engine->date($u['date']." ".$u['time'])?><br> Статус: <span class='label label-success'>Выдано</span>">
      </div>
      <? } ?>
</div>