<?php
echo $Engine->online("slots");