<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/engine/classes/Main.class.php';

$engine = new Engine;

/* Функция проверки айпи */
function getIP() {
    if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
    return $_SERVER['REMOTE_ADDR'];
}

/* Проверка на айпи того, кто заходит на site.ru/payments.php */
if (!in_array(getIP(), array('136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '136.243.38.108'))) {
    die('pizduy otsuda');
}

/* Если всё ок, то передаём дальше платёж на проверку подписи*/
if (isset($_REQUEST['SIGN']) && isset($_REQUEST['AMOUNT']) && isset($_REQUEST['us_account']) && isset($_REQUEST['us_nick'])) {
    $engine->up_sign($_REQUEST,false);
    die('YES');
} else {
    die('NO');
}
