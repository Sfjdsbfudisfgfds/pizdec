<?php
switch ($_GET['type']) {
    case "edit":
        $extra = $Admin->extra($_GET['id']);
        if (!$extra)
            echo $Admin->alert("Сервер не обнаружен!", "danger");
        else {
		if(isset($_POST['update_extra'])) echo $Admin->update_extra($_POST, $extra->id);
?>
    <form method="post">
        <div class="alert alert-dismissible alert-warning">
            <center> Редактирование РКОН данных сервера для выдачи</center>
        </div>
        <input class="form-control" type="hidden" name="id" value="<?=$extra->id?>">
        <div class="form-group">
            <label class="control-label">Название сервера</label>
            <input class="form-control" placeholder="Test" type="text" name="name" value="<?=$extra->name?>">
        </div>
        <div class="form-group">
            <label class="control-label">Адрес сервера</label>
            <input class="form-control" placeholder="127.0.0.1" type="text" name="ip" value="<?=$extra->ip?>">
        </div>
        <div class="form-group">
            <label class="control-label">Порт сервера</label>
            <input class="form-control" placeholder="23141" type="text" name="port" value="<?=$extra->port?>">
        </div>
        <div class="form-group">
            <label class="control-label">Пароль сервера</label>
            <input class="form-control" placeholder="12345612fd" type="text" name="pass" value="<?=$extra->pass?>">
        </div>
            <div class="form-group">
                <label class="control-label">Сервер сортировки</label>
                <select name="server" class="form-control">
				<?php
				 $query = $Admin->engine->query("SELECT * FROM `servers`");
					while ($q = $query->fetch_object()) {
						echo '<option value="'.$q->id.'">'.$q->name.'</option>';
					} ?>
                </select>
            </div>
        <button type="submit" class="btn btn-success btn-block" name="update_extra"><i class="fa fa-plus" aria-hidden="true"></i> Изменить сервер</button>
    </form>
    <?php
        }
    break;
	case "remove":
		$extra = $Admin->extra($_GET['id']);
		if (!$extra)
            echo $Admin->alert("Сервер не обнаружен!", "danger");
        else {
			echo $Admin->alert("Вы собираетесть удалить сервер [{$extra->name}], вы подтверждаете это действие?", "warning");
			if(isset($_GET['delete']))
			{
				$Admin->remove_extra($extra->id);
				echo $Admin->alert("Вы успешно удалили сервер [{$extra->name}]", "success");
			} else echo '<a href="/admin/?action=extradition&type=remove&id='.$extra->id.'&delete" class="btn btn-danger btn-block"><i class="fa fa-times" aria-hidden="true"></i> Удалить сервер</a>';
		}
	break;
	default:
	if(isset($_POST['add_extra'])) echo $Admin->add_extra($_POST);
	?>
        <form method="post">
            <div class="alert alert-dismissible alert-warning">
                <center> Добавление РКОН данных сервера для выдачи</center>
            </div>
            <div class="form-group">
                <label class="control-label">Название сервера</label>
                <input class="form-control" placeholder="Test" type="text" name="name">
            </div>
            <div class="form-group">
                <label class="control-label">Адрес сервера</label>
                <input class="form-control" placeholder="127.0.0.1" type="text" name="ip">
            </div>
            <div class="form-group">
                <label class="control-label">Порт сервера</label>
                <input class="form-control" placeholder="23141" type="text" name="port">
            </div>
            <div class="form-group">
                <label class="control-label">Пароль сервера</label>
                <input class="form-control" placeholder="12345612fd" type="text" name="pass">
            </div>
            <div class="form-group">
                <label class="control-label">Сервер сортировки</label>
                <select name="server" class="form-control">
				<?php
				 $query = $Admin->engine->query("SELECT * FROM `servers`");
					while ($q = $query->fetch_object()) {
						if($q->id == $extra->server) $s = "selected"; else $s = "";
						echo '<option '.$s.' value="'.$q->id.'">'.$q->name.'</option>';
					} ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success btn-block" name="add_extra"><i class="fa fa-plus" aria-hidden="true"></i> Добавить сервер</button>
        </form>
        <?php
}