<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/bs-3.3.5/jq-2.1.4,dt-1.10.8/datatables.min.css" />
<link href="/admin/styles/css/admin.css" rel="stylesheet">
<script type="text/javascript" src="https://cdn.datatables.net/r/bs-3.3.5/jqc-1.11.3,dt-1.10.8/datatables.min.js"></script>
<script>
    $(document).ready(function() {
            $('#donaters').DataTable({
                language: {
                    processing: "Выполняется обработка...",
                    search: "Поиск: ",
                    lengthMenu: "Показать _MENU_ записей",
                    info: "Записи с _START_ до _END_ из _TOTAL_ записей",
                    infoEmpty: "Записи с 0 до 0 из 0 записей",
                    infoFiltered: "<br>(отфильтровано из _MAX_ записей)",
                    infoPostFix: "",
                    loadingRecords: "Загрузка...",
                    zeroRecords: "Записи не обнаружены",
                    emptyTable: "Нет доступных в таблице данных",
                    paginate: {
                        first: "Первая",
                        previous: "Назад",
                        next: "Вперед",
                        last: "Последняя"
                    },
                    aria: {
                        sortAscending: ": активировать для сортировки столбца по возрастанию",
                        sortDescending: ": активировать для сортировки столбцов по убыванию"
                    }
                }
            });
        }

    );
</script>

<table id="donaters" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th style="width: 10px">#</th>
            <th>Ник</th>
            <th>Группа</th>
            <th style="width: 40px">Цена</th>
        </tr>
    </thead>
    <tbody>
       <?=$Admin->all_donaters()?>
    </tbody>
    <tfoot>
        <tr>
            <th style="width: 10px">#</th>
            <th>Ник</th>
            <th>Группа</th>
            <th style="width: 40px">Цена</th>
        </tr>
    </tfoot>
</table>