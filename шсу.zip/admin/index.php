<?php
    @session_start();
    if(!$_SESSION['username'])
    {
        header('location:/admin/login.php');
        exit();
    }
    require_once $_SERVER['DOCUMENT_ROOT'].'/engine/classes/Admin.class.php';
    $Admin = new Admin();

	if(isset($_GET['action'])) $action = $_GET['action'];
	else $action = 'index';
?>
    <!DOCTYPE HTML>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?=$Admin->engine->cfg['server']['name']?> > Панель</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link href="/admin/styles/css/bootstrap.min.css" rel="stylesheet">
        <link href="/admin/styles/css/admin.css" rel="stylesheet">
        <script action="text/javascript" src="/admin/styles/js/bootstrap.min.js"></script>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    </head>

    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button action="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Скрыть навигацию</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="/admin/"><?=$Admin->engine->cfg['server']['name']?> - Панель</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="/console/">Консоль (Бета)</a>
                        </li>
                        <li class="active">
                            <a href="/admin/">Панель</a>
                        </li>
                        <li>
                            <a href="/">Сайт</a>
                        </li>
                        <li>
                            <a href="logout.php">Выйти</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <br>
        <br>
        <br>
        <br>
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title">Действие</h3>
                            </div>
                            <div class="panel-body">
                                <?php
									if(file_exists($_SERVER['DOCUMENT_ROOT'].'/admin/actions/'.$action.'.php'))
										include $_SERVER['DOCUMENT_ROOT'].'/admin/actions/'.$action.'.php';
									else echo $Admin->alert("<b>Ошибка!</b> Страница не найдена!", "danger");
								?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">Товары в продаже</div>
                            <ul class="list-group">
							<?php
							if(!empty($_GET['groups'])) echo $Admin->all_groups((int)$_GET['groups']);
								else echo $Admin->all_servers_groups();
								?>
                            </ul>
                        </div>

                        <a href="/admin/?action=groups" class="btn btn-block btn-primary <?php if($action == " groups ") echo "active ";?>"><i class="fa fa-plus" aria-hidden="true"></i> Добавить группу</a>
                        <hr>

                        <div class="panel panel-default">
                            <div class="panel-heading">Промокоды</div>
                            <ul class="list-group">
                                <?=$Admin->all_promo()?>
                            </ul>
                        </div>

                        <a href="/admin/?action=promo" class="btn btn-block btn-primary <?php if($action == " promo ") echo "active ";?>"><i class="fa fa-plus" aria-hidden="true"></i> Добавить промокод</a>
                        <hr>

                        <div class="panel panel-default">
                            <div class="panel-heading">Сервера сортировки</div>
                            <ul class="list-group">
                                <?=$Admin->all_servers()?>
                            </ul>
                        </div>

                        <a href="/admin/?action=server" class="btn btn-block btn-primary <?php if($action == " server ") echo "active ";?>"><i class="fa fa-plus" aria-hidden="true"></i> Добавить сервер</a>
                        <hr>

                        <div class="panel panel-default">
                            <div class="panel-heading">Сервера выдачи</div>
                            <ul class="list-group">
                                <?=$Admin->all_extradition()?>
                            </ul>
                        </div>
                        <a href="/admin/?action=extradition" class="btn btn-block btn-primary <?php if($action == " server ") echo "active ";?>"><i class="fa fa-plus" aria-hidden="true"></i> Добавить сервер</a>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>