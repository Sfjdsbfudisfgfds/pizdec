<?php
/* Smarty version 3.1.30, created on 2022-01-22 14:31:28
  from "/home/vol1_5/unaux.com/unaux_30763493/htdocs/templates/main.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_61ebeb10a86b50_71491586',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '05f851e8a36874b822c34c9520f8885a3ff8c6f2' => 
    array (
      0 => '/home/vol1_5/unaux.com/unaux_30763493/htdocs/templates/main.html',
      1 => 1642850820,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:messages.html' => 1,
  ),
),false)) {
function content_61ebeb10a86b50_71491586 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<title><?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['name'];?>
 | Игровые сервера Майнкрафт (Minecraft)</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['name'];?>
 | Игровые сервера Майнкрафт (Minecraft)" />
		<link type="image/x-icon" rel="shortcut icon" href="/favicon.ico" />
		<link type="text/css" rel="stylesheet" href="/styles/css/bootstrap.min.css" />
		<link type="text/css" rel="stylesheet" href="/styles/css/animate.min.css" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
		<link type="text/css" rel="stylesheet" rel="stylesheet" href="/styles/css/main.css" />
	</head>
	<body>
	    <div id="page-preloader" class="preloader">
			<div class="loader-text">Добро пожаловать</div>
			<div class="loader"></div>
		</div>

		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container">
				<a class="navbar-brand" href="/"><?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['design_name'];?>
</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNav">
					<ul class="navbar-nav mr-auto">
						<li class="nav-item">
							<a href="/" class="nav-link"><i class="fas fa-home"></i>Главная</a>
						</li>
						<li class="nav-item">
							<a href="https://vk.com/unfixxxvk" target="blank" class="nav-link"><i class="fab fa-vk"></i>Группа ВКонтакте</a>
						</li>
						<!-- Модальные окна -->
						<!-- Контакты -->
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="modal" data-target="#Contacts"><i class="fa fa-address-book"></i> Контакты</a>
						</li>
						<!-- Правила -->
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="modal" data-target="#Rules"><i class="fa fa-info-circle"></i> Правила</a>
						</li>
					</ul>
					<ul class="navbar-nav" id="server-info">
						<li><a href="javascript:" class="btn btn-primary btn-sm">
							Онлайн: <span id="online">0</span> / <span id="slots">0</span></a>
						</li>
						<li><a href="javascript:" class="btn btn-success btn-sm" onclick="prompt('Скопируйте наш IP адрес и вставьте в ваш клиент:','<?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['ip'];?>
'); return false;">
							IP: <?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['ip'];?>

						</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>

		<!-- Модальное окна -->
		<!-- Контакты -->
		<div class="modal fade" id="Contacts" tabindex="-1" role="dialog" aria-labelledby="exampleModal" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="ContactsLabel">Контакты</h5>
						<button class="close" type="button" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<p>Вк: vk.com/unfixxxvk</p>
					</div>
					<div class="modal-footer">
						<button class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
					</div>
				</div>
			</div>
		</div>
		<!-- Правила -->
		<div class="modal fade" id="Rules" tabindex="-1" role="dialog" aria-labelledby="exampleModal" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="RulesLabel">Правила (ВАЖНО)</h5>
						<button class="close" type="button" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="card-header">
						<button type="button" class="btn btn-secondary btn-sm spoiler-trigger" data-toggle="collapse">1. Общие правила</button>
					</div>
					<div class="modal-body">
						<span class="badge badge-pill badge-danger">ВАЖНО</span> Пункт 1.1 - Начав играть на наших серверах, Вы автоматически подтверждаете своё согласие с данным сводом правил.<br /><br />
						<span class="badge badge-pill badge-danger">ВАЖНО</span> Пункт 1.2 - Незнание правил сервера не освобождает вас от ответственности.<br /><br />
						1.4 Администрация не несет ответственности за временную или постоянную невозможность игры на сервере конкретным лицом или группой лиц.<br /><br />
						<span class="badge badge-pill badge-warning">ВАЖНО</span> Пункт 1.5 - Донат - пожертвование серверу на безвозмездной основе, возвращение средств не производится ни при каких условиях.<br /><br />
						1.6 Администрация ведет логи всех действий игроков на сервере и всех сообщений чата.<br /><br />
						1.7 Администрация имеет право корректировать данный свод правил без уведомления игрока.<br /><br />
					</div>
					
					<div class="modal-footer">
						<button class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
					</div>
				</div>
			</div>
		</div>
		<!-- Конец Модальных окон-->

		<main class="container">
			<article>
				<div class="row">
					<div class="col-md-6">
						<?php $_smarty_tpl->_subTemplateRender("file:messages.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

						<ul class="nav nav-tabs" role="tablist">
							<?php echo $_smarty_tpl->tpl_vars['get_servers']->value;?>

						</ul>
						<div class="panel panel-default" style="border-top-left-radius: 0px;border-top-right-radius: 0px; color: white">
							<div class="panel-body">
								<div class="tab-content">
									<?php echo $_smarty_tpl->tpl_vars['get_form']->value;?>

								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<center>
							<div class="alert alert-warning">
								<ul>
									<li>Донат остаётся НАВСЕГДА после покупки.</li>
									<li>Действуют скидки 98% на ВЕСЬ донат.</li>
									<li>Оплата происходит БЕЗ КОМИССИИ через любые платёжные системы.</li>
									<li>Донат выдаётся МОМЕНТАЛЬНО.</li>
									<li>Работает ДОПЛАТА на все донат-услуги.</li>
								</ul>
							</div>
							<p class="text-center"><b>Осталось до завершения акции:</b></p>
							<div class="row">
								<div class="col-md-4">
									<div class="card">
										<div class="card-block">
											<h5 class="second text-danger"></h5>
											<div style="color: white">Часов</div>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="card">
										<div class="card-block">
											<h5 class="third text-danger"></h5>
											<div style="color: white">Минут</div>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="card">
										<div class="card-block">
											<h5 class="four text-danger	"></h5>
											<div style="color: white">Секунд</div>
										</div>
									</div>
								</div>
							</div>
						</center>
					</div>
				</div>
				
				<h2 style="color: white">Последние донатеры:</h2>
				<div class="donat" id="donaters"></div>

			</article>
		</main>

<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-1.11.3.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 src="/styles/js/countdown.js"><?php echo '</script'; ?>
>

         <?php echo '<script'; ?>
>
         var date = new Date();
var day = date.getDate() + 1;
var month = date.getMonth() + 1 ;
if(day >= 32) { day = day - 1 }
$(".row").countdown("2029/" + month + "/" + day, function(event) {
$('.second').text(event.strftime('%H'));
$('.third').text(event.strftime('%M'));
$('.four').text(event.strftime('%S'));
});
<?php echo '</script'; ?>
>
 
		<footer class="footer">
			<div class="container text-center">
				<?php ob_start();
echo date('Y');
$_prefixVariable1=ob_get_clean();
if (2019 != $_prefixVariable1) {?>2019 - <?php }
echo date('Y');?>
 © <?php echo $_smarty_tpl->tpl_vars['cfg']->value['server']['design_name'];?>
.
				Все права защищены! 
			</div>
		</footer>
		<?php echo '<script'; ?>
 src="/styles/js/preloader.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/jquery-3.4.0.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/script.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="/styles/js/valid.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"><?php echo '</script'; ?>
>
	</body>
</html><?php }
}
