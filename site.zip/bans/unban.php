<?php
require_once 'inc/header.php';

echo ' <div class="container"> ';
echo ' <div class="row"> ';

echo '
<div style="color:white" class="col-sm-12">
    <h5 class="test">Chcem si podať žiadosť o unban</h5>
    <p></p>

</div>';

echo '</div>';
echo '</div>';


require_once 'inc/footer.php';