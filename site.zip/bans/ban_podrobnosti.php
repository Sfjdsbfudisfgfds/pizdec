<?php
require_once 'inc/header.php';

$ban["id"] = $_GET["id"];

echo '<div style="margin-top:5%;" class="container"> ';

echo '
<table class="table table-hover table-sm">';
echo ' <tbody> ';

$sql="SELECT * FROM litebans_bans WHERE id='". $ban["id"] ."'";
$result_ban = $conn->query($sql);

if ($result_ban->num_rows > 0) {
    while($row = $result_ban->fetch_assoc()) {

echo '
<tr>
<td>'. $ban_details["id"] .':  <font style="color:rgba(239, 21, 21, 0.74)">'. $row["id"] .'</font></td>
</tr>';


$sql="SELECT name FROM litebans_history WHERE uuid='". $row["uuid"] ."'";
$result_history = $conn->query($sql);

if ($result_history->num_rows > 0) {
    while($history = $result_history->fetch_assoc()) {

	echo '<tr><td>'. $ban_details["banned"] .': <font style="color:rgba(239, 21, 21, 0.74)"> <img class="rounded-circle" src="https://minotar.net/avatar/'. $history["name"] .'/25.png"> '. $history["name"] .'</td></tr></font>';

}
}
$timeEpoch1 = $row["time"];
$timeConvert1 = $timeEpoch1 / 1000;
$time["banned"] = date("Y-m-j H:i ", $timeConvert1);

echo  '<tr><td>'. $ban_details["banned_by"] .':  <font style="color:rgba(239, 21, 21, 0.74)"><img class="rounded-circle" src="https://minotar.net/avatar/'. $row["banned_by_name"] .'/27.png"> '. $row["banned_by_name"] .'</td></font></tr>';
      
if ($row["reason"]) {
	echo '<tr><td>'. $ban_details["reason"] .': <font style="color:rgba(239, 21, 21, 0.74)">'. $row["reason"] .'</font></td></tr>';
}else{
	echo '<tr><td style="color:rgba(238, 183, 17, 0.81)">'. $ban_details["reason"] .': <font style="color:rgba(239, 21, 21, 0.74)">'. $ban_details["reason_none"] .'</font> </tr></td>';
}
echo '<tr><td>'. $ban_details["banned_time"] .': <font style="color:rgba(239, 21, 21, 0.74)">'. $time["banned"] .'</font></td></tr> ';

if ($row["ipban"] == 1){
	echo '<tr><td>'. $ban_details["activity"] .': <font style="color:rgba(237, 18, 18, 0.72)">'. $ban_details["reason_permanent"] .'</font></td></td> ';
	echo '<tr><td>'. $ban_details["unban"] .': <a href="unban"> <font style="color:rgba(237, 18, 18, 0.72)">'. $ban_details["buy_unban"] .'</font></a></td> </td>';
}else{

if ($row["removed_by_name"]) {
	echo '<tr><td style="color:rgba(238, 183, 17, 0.81)">'. $ban_details["unbanned_by"] .' '. $row["removed_by_name"] .'</td></td>';
}else{

if ($row["active"] == 1) {
	echo '
	<tr><td>'. $ban_details["activity"] .': <font style="color:rgba(237, 18, 18, 0.72)">'. $ban_details["active"] .'</font></td> </td>
	<tr><td>Unban: <a href="unban"> <font style="color:rgba(237, 18, 18, 0.72)">'. $ban_details["buy_unban"] .'</font></a></td> </td>
	';
}else{
	echo '<tr><td>'. $ban_details["activity"] .': <font style="color:rgba(40, 201, 19, 1)">'. $ban_details["deactive"] .'</font></td></td>';
}

}
}

echo '</tr>';


}
}else{
echo '
<div class="notice notice-success">
<img weight="40" height="50" src="'. $web["link"] .'assets/img/creeper_warn.png">
    <strong>'. $web["name"] .'</strong> '. $ban_details["ban_not_exist"] .'
</div>
';
}



echo ' </tbody> ';
echo ' </table> ';

echo ' </div> ';


require_once 'inc/footer.php';
?>