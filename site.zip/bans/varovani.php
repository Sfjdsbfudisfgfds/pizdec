<?php
require_once 'inc/header.php';

echo '<div style="margin-top:5%;" class="container"> ';

echo '
<table class="table table-hover table-sm">
  <thead style="color:purple">
    <tr>
      <th scope="col">'. $warn["id"] .'</th>
      <th scope="col">'. $warn["warned"] .'</th>
      <th scope="col">'. $warn["warned_by"] .'</th>
      <th scope="col">'. $warn["reason"] .'</th>
      <th scope="col">'. $warn["warning_time"] .'</th>
      <th scope="col">'. $warn["sender_action"] .'</th>
    </tr>
  </thead>';
echo ' <tbody> ';
echo ' <tr>';

$sql="SELECT * FROM litebans_warnings";
$result_ban = $conn->query($sql);

if ($result_ban->num_rows > 0) {
    while($row = $result_ban->fetch_assoc()) {

echo '<td>'. $row["id"] .'</td>';


$sql="SELECT name FROM litebans_history WHERE uuid='". $row["uuid"] ."'";
$result_history = $conn->query($sql);

if ($result_history->num_rows > 0) {
    while($history = $result_history->fetch_assoc()) {

	echo '<td> <img class="rounded-circle" src="https://minotar.net/avatar/'. $history["name"] .'/25.png"> '. $history["name"] .'</td>';

}
}
$timeEpoch1 = $row["time"];
$timeConvert1 = $timeEpoch1 / 1000;
$time["banned"] = date("Y-m-j H:i ", $timeConvert1);

echo  '<td><img class="rounded-circle" src="https://minotar.net/avatar/'. $row["banned_by_name"] .'/27.png"> '. $row["banned_by_name"] .'</td>';

if ($row["reason"]) {
  echo '<td>'. $row["reason"] .'</td>';
}else{
  echo '<td style="color:rgba(238, 183, 17, 0.81)"> '. $warn["reason_none"] .' </td>';
}

echo '<td>'. $time["banned"] .'</td>';

if ($row["active"] == 1) {
	echo '
	<td style="color:rgba(237, 18, 18, 0.72)">'. $warn["active"] .'</td> 
	<td><a style="text-decoration:none;color:rgba(214, 29, 0, 0.87)" href="unban">'. $warn["remove"] .'</a></td>
	';
}else{
	echo '<td style="color:rgba(40, 201, 19, 1)">'. $warn["deactive"] .'</td>';
}


echo '</tr>';


}
}else{
echo '
<div class="notice notice-success">
<img weight="40" height="50" src="'. $web["link"] .'assets/img/creeper_info.png">
    <strong>'. $web["name"] .'</strong> '. $warn["no_warn"] .'
</div>
';
}



echo ' </tbody> ';
echo ' </table> ';

echo ' </div> ';


require_once 'inc/footer.php';
?>