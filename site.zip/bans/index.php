<?php 
echo ' <script> window.location.href="ban" </script> ';
?>
