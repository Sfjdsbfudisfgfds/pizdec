<?php

/* Navigator menu  */
$navbar["ban"] = 'Bany';
$navbar["kick"] = 'Vyhodenia';
$navbar["mute"] = 'Umlčania';
$navbar["warn"] = 'Varovania';

/* Table ban's */
$ban["id"] = 'ID';
$ban["banned"] = 'Meno';
$ban["banned_by"] = 'Zabanováný kým';
$ban["reason"] = 'Dôvod banu';
$ban["banned_on"] = 'Zabanováný kedy';
$ban["activity"] = 'Aktivita';
$ban["action"] = 'Akcia';
$ban["unbanned_by"] = 'Odbanovaný od';

$ban["reason_none"] = 'Dôvod nedodaný';
$ban["reason_permanent"] = 'Permament';

$ban["active"] = 'Aktivní';
$ban["deactive"] = 'Vypršal';

$ban["search_all_onban"] = 'Podrobnosti';

$ban["ban_not_exist"] = 'Tento ban neexistuje';
$ban["no_banned"] = 'Nikdo nebol zabanovaný na serveri.';

//ban detail's
$ban_details["id"] = 'ID banu';
$ban_details["banned"] = 'Zabanovaný Hráč';
$ban_details["banned_by"] = 'Zabanovaný kým';
$ban_details["reason"] = 'Dôvod banu';
$ban_details["banned_time"] = 'Zabanovaný kedy';
$ban_details["activity"] = 'Zabanovaní';
$ban_details["reason_permanent"] = 'Permament';
$ban_details["unbanned_by"] = 'Odbanovaný od';
$ban_details["unban"] = 'Unban';
$ban_details["buy_unban"] = 'Kúpit si unban';
$ban_details["reason_none"] = 'Dôvod nedodaný';
$ban_details["active"] = 'Aktivní';
$ban_details["deactive"] = 'Vypršal';

$ban_details["ban_not_exist"] = 'Tento ban neexistuje';


/* Table Kick's */ 
$kick["id"] = 'ID';
$kick["kicked"] = 'Meno';
$kick["kicked_by"] = 'Vyhodený kým';
$kick["reason"] = 'Dôvod vyhodenia';
$kick["kicked_time"] = 'Vyhoden kedy';
$kick["reason_none"] = 'Dôvod nedodaný';

$kick["no_kicked"] = 'Nikdo nebol vyhodený zo serveru.';

/* Table Mute's */
$mute["id"] = 'ID';
$mute["muted"] = 'Meno';
$mute["muted_by"] = 'Umlčaný kým';
$mute["reason"] = 'Dôvod umlčania';
$mute["muted_time"] = 'Umlčaný kedy';
$mute["activity"] = 'Aktivita';

$mute["unmuted_by"] = 'Odmlčaný od';
$mute["reason_none"] = 'Dôvod nedodaný';
$mute["reason_permanent"] = 'Permament';

$mute["active"] = 'Aktivní';
$mute["deactive"] = 'Vypršal';

$mute["no_muted"] = 'Nikto nie je umlčaný na serveru.';

/* Table Warn's */
$warn["id"] = 'ID';
$warn["warned"] = 'Meno';
$warn["warned_by"] = 'Varovaný kým';
$warn["reason"] = 'Dôvod varovánia';
$warn["warning_time"] = 'Varovaný kedy';
$warn["sender_action"] = 'Varovanie doručené';
$warn["reason_none"] = 'Dôvod nedodaný';

$warn["active"] = 'Aktivní';
$warn["deactive"] = 'Vypršal';

$warn["remove"] = 'Zrusiť varovanie';

$warn["no_warn"] = 'Nikto nie je varovaný na serveri.';

?>