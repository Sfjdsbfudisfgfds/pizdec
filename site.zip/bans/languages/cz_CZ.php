<?php

/* Navigator menu  */
$navbar["ban"] = 'Bany';
$navbar["kick"] = 'Vyhození';
$navbar["mute"] = 'Umlčení';
$navbar["warn"] = 'Varovaní';

/* Table ban's */
$ban["id"] = 'ID';
$ban["banned"] = '	Jméno';
$ban["banned_by"] = 'Zabanován kým';
$ban["reason"] = 'Důvod banu';
$ban["banned_on"] = 'Zabanován kdy';
$ban["activity"] = 'Aktivita';
$ban["action"] = 'Akcia';
$ban["unbanned_by"] = 'Odbanován od';

$ban["reason_none"] = 'Důvod nedodán';
$ban["reason_permanent"] = 'Permament';

$ban["active"] = 'Aktivní';
$ban["deactive"] = 'Vypršal';

$ban["search_all_onban"] = 'Podrobnosti';

$ban["ban_not_exist"] = 'Tento ban neexistuje';
$ban["no_banned"] = 'Nikdo nebyl zabanován na serveru.';

//ban detail's
$ban_details["id"] = 'ID banu';
$ban_details["banned"] = 'Zabanován Hráč';
$ban_details["banned_by"] = 'Zabanován kým';
$ban_details["reason"] = 'Důvod banu';
$ban_details["banned_time"] = 'Zabanován kdy';
$ban_details["activity"] = 'Zabanovaní';
$ban_details["reason_permanent"] = 'Permament';
$ban_details["unbanned_by"] = 'Odbanován od';
$ban_details["unban"] = 'Unban';
$ban_details["buy_unban"] = 'Koupit si unban';
$ban_details["reason_none"] = 'Důvod nedodán';
$ban_details["active"] = 'Aktivní';
$ban_details["deactive"] = 'Vypršal';

$ban_details["ban_not_exist"] = 'Tento ban neexistuje';


/* Table Kick's */ 
$kick["id"] = 'ID';
$kick["kicked"] = 'Jméno';
$kick["kicked_by"] = 'Vyhozen kým';
$kick["reason"] = 'Důvod vyhození';
$kick["kicked_time"] = 'Vyhozen kdy';
$kick["reason_none"] = 'Důvod nedodán';

$kick["no_kicked"] = 'Nikdo nebyl vyhozen ze serveru.';

/* Table Mute's */
$mute["id"] = 'ID';
$mute["muted"] = 'Jméno';
$mute["muted_by"] = 'Umlčen kým';
$mute["reason"] = 'Důvod umlčení';
$mute["muted_time"] = 'Umlčen kdy';
$mute["activity"] = 'Aktivita';

$mute["unmuted_by"] = 'Odmlčen od';
$mute["reason_none"] = 'Důvod nedodán';
$mute["reason_permanent"] = 'Permament';

$mute["active"] = 'Aktivní';
$mute["deactive"] = 'Vypršal';

$mute["no_muted"] = 'Nikto nie je umlčen na serveru.';

/* Table Warn's */
$warn["id"] = 'ID';
$warn["warned"] = 'Jméno';
$warn["warned_by"] = 'Varován kým';
$warn["reason"] = 'Důvod varování';
$warn["warning_time"] = 'Varován kdy';
$warn["sender_action"] = 'Varování doručeno';
$warn["reason_none"] = 'Důvod nedodán';

$warn["active"] = 'Aktivní';
$warn["deactive"] = 'Vypršal';

$warn["remove"] = 'Zrusiť varování';

$warn["no_warn"] = 'Nikto nie je varován na serveru.';

?>