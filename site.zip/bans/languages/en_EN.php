<?php

/* Navigator menu  */
$navbar["ban"] = 'Bans';
$navbar["kick"] = 'Kicks';
$navbar["mute"] = 'Mutes';
$navbar["warn"] = 'Warnings';

/* Table ban's */
$ban["id"] = 'ID';
$ban["banned"] = 'Banned';
$ban["banned_by"] = 'Banned by';
$ban["reason"] = 'Reason';
$ban["banned_on"] = 'Banned time';
$ban["activity"] = 'Activity';
$ban["action"] = 'Action';
$ban["unbanned_by"] = 'Unbanned by';

$ban["reason_none"] = 'None reason';
$ban["reason_permanent"] = 'Permament';

$ban["active"] = 'Active';
$ban["deactive"] = 'Unactive';

$ban["search_all_onban"] = 'Details';

$ban["ban_not_exist"] = 'This ban doesnt exist.';
$ban["no_banned"] = 'No more bans on this server.';

//ban detail's
$ban_details["id"] = 'ID ban';
$ban_details["banned"] = 'Banned';
$ban_details["banned_by"] = 'Banned by';
$ban_details["reason"] = 'Reason';
$ban_details["banned_time"] = 'Banned time';
$ban_details["activity"] = 'Banned';
$ban_details["reason_permanent"] = 'Permament';
$ban_details["unbanned_by"] = 'Unbanned by';
$ban_details["unban"] = 'Unban';
$ban_details["buy_unban"] = 'Buy unban';
$ban_details["reason_none"] = 'None reason';
$ban_details["active"] = 'Active';
$ban_details["deactive"] = 'Expire';

$ban_details["ban_not_exist"] = 'This ban doesnt exist.';


/* Table Kick's */ 
$kick["id"] = 'ID';
$kick["kicked"] = 'Kicked';
$kick["kicked_by"] = 'Kicked by';
$kick["reason"] = 'Reason';
$kick["kicked_time"] = 'Kicked time';
$kick["reason_none"] = 'None reason';

$kick["no_kicked"] = 'No more kicks on this server.';

/* Table Mute's */
$mute["id"] = 'ID';
$mute["muted"] = 'Mated';
$mute["muted_by"] = 'Muted by';
$mute["reason"] = 'Reason';
$mute["muted_time"] = 'Muted time';
$mute["activity"] = 'Activity';

$mute["unmuted_by"] = 'UnMuted by';
$mute["reason_none"] = 'None reason';
$mute["reason_permanent"] = 'Permament';

$mute["active"] = 'Active';
$mute["deactive"] = 'Unactive';

$mute["no_muted"] = 'No more mutes on this server.';

/* Table Warn's */
$warn["id"] = 'ID';
$warn["warned"] = 'Warned';
$warn["warned_by"] = 'Warned by';
$warn["reason"] = 'Reason';
$warn["warning_time"] = 'Warned time';
$warn["sender_action"] = 'Warned send';
$warn["reason_none"] = 'None reason';

$warn["active"] = 'Active';
$warn["deactive"] = 'Unactive';

$warn["remove"] = 'Remove warn';

$warn["no_warn"] = 'No more warns on this server.';

?>