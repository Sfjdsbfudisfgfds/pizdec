<?php
require_once 'inc/header.php';

echo '<div style="margin-top:5%;" class="container"> ';

echo '
<table class="table table-hover table-sm">
  <thead style="color:purple">
    <tr>
      <th scope="col">'. $mute["id"] .'</th>
      <th scope="col">'. $mute["muted"] .'</th>
      <th scope="col">'. $mute["muted_by"] .'</th>
      <th scope="col">'. $mute["reason"] .'</th>
      <th scope="col">'. $mute["muted_time"] .'</th>
      <th scope="col">'. $mute["activity"] .'</th>
    </tr>
  </thead>';
echo ' <tbody> ';
echo ' <tr>';

$sql="SELECT * FROM litebans_mutes";
$result_ban = $conn->query($sql);

if ($result_ban->num_rows > 0) {
    while($row = $result_ban->fetch_assoc()) {

echo '<td>'. $row["id"] .'</td>';


$sql="SELECT name FROM litebans_history WHERE uuid='". $row["uuid"] ."'";
$result_history = $conn->query($sql);

if ($result_history->num_rows > 0) {
    while($history = $result_history->fetch_assoc()) {

	echo '<td> <img class="rounded-circle" src="https://minotar.net/avatar/'. $history["name"] .'/25.png"> '. $history["name"] .'</td>';

}
}
$timeEpoch1 = $row["time"];
$timeConvert1 = $timeEpoch1 / 1000;
$time["banned"] = date("Y-m-j H:i ", $timeConvert1);

echo  '<td><img class="rounded-circle" src="https://minotar.net/avatar/'. $row["banned_by_name"] .'/27.png"> '. $row["banned_by_name"] .'</td>';

if ($row["reason"]) {
  echo '<td>'. $row["reason"] .'</td>';
}else{
  echo '<td style="color:rgba(238, 183, 17, 0.81)"> '. $mute["reason_none"] .' </td>';
}

echo '<td>'. $time["banned"] .'</td>';
if ($row["ipban"] == 1){
	echo '<td style="color:rgba(237, 18, 18, 0.72)">'. $mute["reason_permanent"] .'</td> ';
}else{

if ($row["removed_by_name"]) {
	echo '<td style="color:rgba(238, 183, 17, 0.81)">'. $mute["unmuted_by"] .' '. $row["removed_by_name"] .'</td>';
  echo '<td style="text-decoration:none;color:rgba(214, 29, 0, 0.87)" >'. $mute["unmuted_by"] .'</td>';
}else{

if ($row["active"] == 1) {
	echo '
	<td style="color:rgba(237, 18, 18, 0.72)">'. $mute["active"] .'</td> 
	';
}else{
	echo '<td style="color:rgba(40, 201, 19, 1)">'. $mute["deactive"] .'</td>';
}

}
}

echo '</tr>';


}
}else{
echo '
<div class="notice notice-success">
<img weight="40" height="50" src="'. $web["link"] .'assets/img/creeper_info.png">
    <strong>'. $web["name"] .'</strong> '. $mute["no_muted"] .'
</div>
';
}



echo ' </tbody> ';
echo ' </table> ';

echo ' </div> ';


require_once 'inc/footer.php';
?>