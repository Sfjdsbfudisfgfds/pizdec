<?php
/* settings banlist // SETTING LINK because banlist is dont work! */
$web["name"] = 'InSites.sk';
$web["link"] = 'http://banlistmc.insites.sk/';
$web["language"] = 'en_EN'; /* en_EN | sk_SK | cz_CZ */
$web["main_logo"] = 'logo.png';
$web["forum_link"] = 'https://www.insites.sk/forum/view/19-ziadost-o-unban';


/* Database setings */ 

//Connecting database
$dbhost = 'localhost';  //Database host 
$dbuser = 'user';    //Databse username
$dbpass = 'password';  //Database Heslo
$dbname = 'name';  //Database name

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$conn->set_charset("utf8");

?>
