<?php

//Odstráni známe prípony súborov .php
$web["page"] = basename($_SERVER["SCRIPT_NAME"], '.php');

?>