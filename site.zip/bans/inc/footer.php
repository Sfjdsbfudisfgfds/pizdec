<?php

echo '
<div class="footer">
   <div class="container">
   © '. date("Y") .' <a href="https://warfaremc.eu">'. $web["name"] .'</a> Kopírovanie webového obsahu, alebo jeho kódu je prísne zakázané!
   <br />
    Banlist pre <a href="https://warfaremc.eu">'. $web["name"] .'</a> navrhól a nakódoval <a href="https://www.facebook.com/tsad21?ref=bookmarks">Ax1sss</a>
   </div>
</div>
';

echo '<script src="'. $web["link"] .'assets/js/mdb.lite.min.js"></scropt>';
echo '<script src="'. $web["link"] .'assets/js/bootstrap.min.js"></script>';
echo '<script src="'. $web["link"] .'assets/js/bootstrap.js"></script>';
echo '<script src="'. $web["link"] .'assets/js/jquery.min.js"></script>';
echo '<script src="'. $web["link"] .'assets/js/main.min.js"></script>';
?>