<?php
require_once 'config.php';
require_once 'functions.php';
include 'languages/'.$web["language"].'.php';

echo ' <!DOCTYPE html> ';
echo ' <html lang="cs"> ';
echo ' <head> ';
echo ' <title>'. $web["name"] .' | Banlist '. date("Y") .'</title> ';
echo ' <link rel="stylesheet" type="text/css" href="'. $web["link"] .'assets/css/main.css"> ';
echo ' <link rel="stylesheet" type="text/css" href="'. $web["link"] .'assets/css/bootstrap.min.css"> ';
echo ' <link rel="stylesheet" type="text/css" href="'. $web["link"] .'assets/css/bootstrap.css"> ';
echo ' <link rel="stylesheet" type="text/css" href="'. $web["link"] .'assets/css/mdb.lite.min.css"> ';
echo ' <link rel="shortcut icon" href="'. $web["link"] .'assets/img/favicon.ico" />';
echo ' </head> ';
echo ' <body> ';

echo '<img src="'. $web["link"] .'assets/img/'. $web["main_logo"] .'" title="'. $web["name"] .' Logo" alt="'. $web["name"] .' Logo" class="element" /> ';


echo ' <nav class="navbar navbar-expand-lg navbar-dark fixed-top" role="navigation"> ';
echo ' <div class="container"> ';
echo ' <a class="navbar-brand" href="'. $web["link"] .'">'. $web["name"] .'</a> ';
echo ' <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#exCollapsingNavbar">&#9776;</button> ';
echo ' <div class="collapse navbar-collapse" id="exCollapsingNavbar"> ';
echo ' <ul class="nav navbar-nav"> ';

if ($web["page"] == 'ban') {
	echo ' <div class="line"><li class="nav-item"><a style="color:white" href="'. $web["link"] .'ban" class="nav-link">'. $navbar["ban"] .'</a></li></div> ';
}else{
	echo ' <li class="nav-item"><a href="'. $web["link"] .'ban" class="nav-link">'. $navbar["ban"] .'</a></li> ';
}

if ($web["page"] == 'vyhozeni') {
	echo ' <div class="line"><li class="nav-item"><a style="color:white" href="'. $web["link"] .'vyhozeni" class="nav-link">'. $navbar["kick"] .'</a></li></div> ';
}else{
	echo ' <li class="nav-item"><a href="'. $web["link"] .'vyhozeni" class="nav-link">'. $navbar["kick"] .'</a></li> ';
}

if ($web["page"] == 'umlceni') {
	echo ' <div class="line"><li class="nav-item"><a style="color:white" href="'. $web["link"] .'umlceni" class="nav-link">'. $navbar["mute"] .'</a></li></div> ';
}else{
	echo ' <li class="nav-item"><a href="'. $web["link"] .'umlceni" class="nav-link">'. $navbar["mute"] .'</a></li> ';
}

if ($web["page"] == 'varovani') {
	echo ' <div class="line"><li class="nav-item"><a style="color:white" href="'. $web["link"] .'varovani" class="nav-link">'. $navbar["warn"] .'</a></li></div> ';
}else{
	echo ' <li class="nav-item"><a href="'. $web["link"] .'varovani" class="nav-link">'. $navbar["warn"] .'</a></li> ';
}



echo ' </ul> ';
echo ' </div> ';
echo ' </div> ';
echo ' </nav> ';

?>
