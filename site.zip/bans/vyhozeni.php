<?php
require_once 'inc/header.php';


echo '<div style="margin-top:5%;" class="container"> ';

echo '
<table class="table table-hover table-sm">
  <thead style="color:purple">
    <tr>
      <th scope="col">'. $kick["id"] .'</th>
      <th scope="col">'. $kick["kicked"] .'</th>
      <th scope="col">'. $kick["kicked_by"] .'</th>
      <th scope="col">'. $kick["reason"] .'</th>
      <th scope="col">'. $kick["kicked_time"] .'</th>
    </tr>
  </thead>';
echo ' <tbody> ';
echo ' <tr>';

$sql="SELECT * FROM litebans_kicks";
$result_ban = $conn->query($sql);

if ($result_ban->num_rows > 0) {
    while($row = $result_ban->fetch_assoc()) {

echo '<td>'. $row["id"] .'</td>';


$sql="SELECT name FROM litebans_history WHERE uuid='". $row["uuid"] ."'";
$result_history = $conn->query($sql);

if ($result_history->num_rows > 0) {
    while($history = $result_history->fetch_assoc()) {

	echo '<td> <img class="rounded-circle" src="https://minotar.net/avatar/'. $history["name"] .'/25.png"> '. $history["name"] .'</td>';

}
}
$timeEpoch1 = $row["time"];
$timeConvert1 = $timeEpoch1 / 1000;
$time["kicked"] = date("Y-m-j H:i ", $timeConvert1);

echo  '
      <td><img class="rounded-circle" src="https://minotar.net/avatar/'. $row["banned_by_name"] .'/27.png"> '. $row["banned_by_name"] .'</td>';
      
if ($row["reason"]) {
	echo '<td>'. $row["reason"] .'</td>';
}else{
	echo '<td style="color:rgba(238, 183, 17, 0.81)"> '. $kick["reason_none"] .' </td>';
}

echo ' <td>'. $time["kicked"] .'</td>';

echo '</tr>';


}
}else{
echo '
<div class="notice notice-success">
<img weight="40" height="50" src="'. $web["link"] .'assets/img/creeper_info.png">
    <strong>'. $web["name"] .'</strong> '. $kick["no_kicked"] .'
</div>
';
}



echo ' </tbody> ';
echo ' </table> ';

echo ' </div> ';


require_once 'inc/footer.php';
?>
