<?php
$ourData = file_get_contents("core/lang/en_EN.json" );
$getLang = json_decode($ourData, true);

session_start();
if ($_SESSION['player']){
    header("Location: account");
}


?>


<html lang="en" dir="" class="h-100">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $getLang['main']['ServerName']?> - <?= $getLang['login']['title']?></title>
    <link rel="shortcut icon" href="./favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./assets/css/vendor.min.css">
    <link rel="stylesheet" href="./assets/vendor/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="./assets/css/theme.min.css?v=1.0">
    <style class="fslightbox-styles">.fslightbox-absoluted{position:absolute;top:0;left:0}.fslightbox-fade-in{animation:fslightbox-fade-in .3s cubic-bezier(0,0,.7,1)}.fslightbox-fade-out{animation:fslightbox-fade-out .3s ease}.fslightbox-fade-in-strong{animation:fslightbox-fade-in-strong .3s cubic-bezier(0,0,.7,1)}.fslightbox-fade-out-strong{animation:fslightbox-fade-out-strong .3s ease}@keyframes fslightbox-fade-in{from{opacity:.65}to{opacity:1}}@keyframes fslightbox-fade-out{from{opacity:.35}to{opacity:0}}@keyframes fslightbox-fade-in-strong{from{opacity:.3}to{opacity:1}}@keyframes fslightbox-fade-out-strong{from{opacity:1}to{opacity:0}}.fslightbox-cursor-grabbing{cursor:grabbing}.fslightbox-full-dimension{width:100%;height:100%}.fslightbox-open{overflow:hidden;height:100%}.fslightbox-flex-centered{display:flex;justify-content:center;align-items:center}.fslightbox-opacity-0{opacity:0!important}.fslightbox-opacity-1{opacity:1!important}.fslightbox-scrollbarfix{padding-right:17px}.fslightbox-transform-transition{transition:transform .3s}.fslightbox-container{font-family:Arial,sans-serif;position:fixed;top:0;left:0;background:linear-gradient(rgba(30,30,30,.9),#000 1810%);touch-action:none;z-index:1000000000;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.fslightbox-container *{box-sizing:border-box}.fslightbox-svg-path{transition:fill .15s ease;fill:#ddd}.fslightbox-nav{height:45px;width:100%;position:absolute;top:0;left:0}.fslightbox-slide-number-container{display:flex;justify-content:center;align-items:center;position:relative;height:100%;font-size:15px;color:#d7d7d7;z-index:0;max-width:55px;text-align:left}.fslightbox-slide-number-container .fslightbox-flex-centered{height:100%}.fslightbox-slash{display:block;margin:0 5px;width:1px;height:12px;transform:rotate(15deg);background:#fff}.fslightbox-toolbar{position:absolute;z-index:3;right:0;top:0;height:100%;display:flex;background:rgba(35,35,35,.65)}.fslightbox-toolbar-button{height:100%;width:45px;cursor:pointer}.fslightbox-toolbar-button:hover .fslightbox-svg-path{fill:#fff}.fslightbox-slide-btn-container{display:flex;align-items:center;padding:12px 12px 12px 6px;position:absolute;top:50%;cursor:pointer;z-index:3;transform:translateY(-50%)}@media (min-width:476px){.fslightbox-slide-btn-container{padding:22px 22px 22px 6px}}@media (min-width:768px){.fslightbox-slide-btn-container{padding:30px 30px 30px 6px}}.fslightbox-slide-btn-container:hover .fslightbox-svg-path{fill:#f1f1f1}.fslightbox-slide-btn{padding:9px;font-size:26px;background:rgba(35,35,35,.65)}@media (min-width:768px){.fslightbox-slide-btn{padding:10px}}@media (min-width:1600px){.fslightbox-slide-btn{padding:11px}}.fslightbox-slide-btn-container-previous{left:0}@media (max-width:475.99px){.fslightbox-slide-btn-container-previous{padding-left:3px}}.fslightbox-slide-btn-container-next{right:0;padding-left:12px;padding-right:3px}@media (min-width:476px){.fslightbox-slide-btn-container-next{padding-left:22px}}@media (min-width:768px){.fslightbox-slide-btn-container-next{padding-left:30px}}@media (min-width:476px){.fslightbox-slide-btn-container-next{padding-right:6px}}.fslightbox-down-event-detector{position:absolute;z-index:1}.fslightbox-slide-swiping-hoverer{z-index:4}.fslightbox-invalid-file-wrapper{font-size:22px;color:#eaebeb;margin:auto}.fslightbox-video{object-fit:cover}.fslightbox-youtube-iframe{border:0}.fslightbox-loader{display:block;margin:auto;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:67px;height:67px}.fslightbox-loader div{box-sizing:border-box;display:block;position:absolute;width:54px;height:54px;margin:6px;border:5px solid;border-color:#999 transparent transparent transparent;border-radius:50%;animation:fslightbox-loader 1.2s cubic-bezier(.5,0,.5,1) infinite}.fslightbox-loader div:nth-child(1){animation-delay:-.45s}.fslightbox-loader div:nth-child(2){animation-delay:-.3s}.fslightbox-loader div:nth-child(3){animation-delay:-.15s}@keyframes fslightbox-loader{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}.fslightbox-source{position:relative;z-index:2;opacity:0}</style>

</head>
<body class="d-flex align-items-center min-h-100">
<main class="flex-grow-1">
    <div class="container-fluid">
        <div class="row">
            <div class="d-flex justify-content-center align-items-center min-vh-lg-100">
                <div class="flex-grow-1 mx-auto" style="max-width: 28rem;">
                    <div class="text-center mb-5 mb-md-7">
                        <h1 class="h2"><?= $getLang['main']['ServerName']?></h1>
                        <p><?= $getLang['login']['form_description']?></p>
                    </div>
                    <form>
                        <div class="mb-4">
                            <div class="input-group input-group-merge" data-hs-validation-validate-class="">
                                <input type="password" class="form-control form-control-lg" name="api" placeholder="<?= $getLang['login']['form_inputPlaceholder']?>" aria-label="8+ characters required" required="" minlength="30">
                            </div>
                            <span class="invalid-feedback"><?= $getLang['login']['empty_input'] ?></span>
                        </div>
                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-block btn-primary login-btn ramove-btn">Sign in</button>
                            <button type="submit" class="btn btn-block btn-primary login-btn loader" style="display: none;" disabled><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></button>
                        </div>
                    </form>
                    <div class="error-id" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
                        <div class="alert alert-danger alert-dismissible fade show msg" role="alert">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tio-clear tio-lg"></i>
                          </button>
                        </div>
                    </div>
                    <div class="success-id" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">Success, redirecting...
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <i class="tio-clear tio-lg"></i>
                              </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<style>
    .error-id {
        display: none;
    }
    .success-id {
        display: none;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/theme.min.js"></script>
<script type="text/javascript">


    $('.login-btn').click(function (e) {
        e.preventDefault();
        let api = $('input[name="api"]').val()
        $.ajax({
            url: 'core/login.php',
            type: 'POST',
            dataType: 'json',
            data: {
                api: api,
            },
            beforeSend:function(){
                $('.loader').show();
                $('.ramove-btn').hide();
            },
            success (data) {
                if (data.status) {
                    setTimeout(function(){
                        window.location.href = 'account';
                    }, 2 * 1000);
                    $('.success-id').show();
                    $('.loader').hide();
                    $('.ramove-btn').show();
                } else {
                    $('.msg').removeClass('display-none').text(data.msg);
                    $('.loader').hide();
                    $('.error-id').show();
                    $('.ramove-btn').show();
                }
            }
        });
    });
</script>
</body>
</html>