<?php
session_start();
if (!$_SESSION['player']){
    header('Location: ../login');
}
    use hengab\BCAPI;
    require_once('../core/BCAPI.php');
    $playerSession = $_SESSION['player'];
    $getBCAPI = new BCAPI($playerSession);

$ourData = file_get_contents("../core/lang/en_EN.json" );
$getLang = json_decode($ourData, true);

?>


<!DOCTYPE html>
<html lang="en" dir="">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?= $getLang['main']['ServerName']?> - <?= $getLang['profile']['title']?></title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/vendor.min.css">
  <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/font/bootstrap-icons.css">
  <link rel="stylesheet" href="../assets/css/theme.min.css?v=1.0">
</head>

<body>
  <header id="header" class="navbar navbar-expand-lg navbar-end navbar-light bg-white">
    <? require_once("../core/html/header.php")?>
  </header>
  <main id="content" role="main" class="bg-light">
    <div class="" style="background-image: url(../assets/img/home/1.png);">
      <div class="container content-space-1 content-space-b-lg-3">
        <div class="row align-items-center">
          <div class="col">
            <div class="d-none d-lg-block">
              <h1 class="h2 text-white">Personal info</h1>
            </div>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb breadcrumb-light mb-0">
                <li class="breadcrumb-item">Account</li>
                <li class="breadcrumb-item active" aria-current="page">Personal Info</li>
              </ol>
            </nav>
          </div>

          <div class="col-auto">
            <div class="d-none d-lg-block">
              <a class="btn btn-soft-light btn-sm" href="../core/logout.php">Log out</a>
            </div>

            <!-- Responsive Toggle Button -->
            <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarNav" aria-controls="sidebarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-default">
                <i class="bi-list"></i>
              </span>
              <span class="navbar-toggler-toggled">
                <i class="bi-x"></i>
              </span>
            </button>
            <!-- End Responsive Toggle Button -->
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Content -->
    <div class="container content-space-1 content-space-t-lg-0 content-space-b-lg-2 mt-lg-n10">
      <div class="row">
        <div class="col-lg-3">
          <!-- Navbar -->
          <div class="navbar-expand-lg navbar-light">
            <div id="sidebarNav" class="collapse navbar-collapse navbar-vertical">
              <!-- Card -->
              <div class="card flex-grow-1 mb-5">
                <div class="card-body">
                  <!-- Avatar -->
                  <div class="d-none d-lg-block text-center mb-5">
                    <div class="avatar avatar-xxl mb-3">
                      <img class="avatar-img" src="https://minotar.net/helm/<?= $getBCAPI->getName()?>">                      
                    </div>

                    <h4 class="card-title mb-0"><?= $getBCAPI->getName()?></h4>
                    <p class="card-text small"><?= $getBCAPI->getCoins()?> <?= $getLang['balance']['balanceName']?></p>
                  </div>
                  <!-- End Avatar -->

                  <!-- Nav -->
                  <span class="text-cap">Account</span>

                  <!-- List -->
                  <ul class="nav nav-sm nav-tabs nav-vertical mb-4">
                    <li class="nav-item">
                      <a class="nav-link active">
                        <i class="bi-person-badge nav-icon"></i> Personal info
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <!-- End Card -->
            </div>
          </div>
          <!-- End Navbar -->
        </div>
        <!-- End Col -->

        <div class="col-lg-9">
          <div class="d-grid gap-3 gap-lg-5">            
            <div class="card">
              <div class="card-header border-bottom">
                <h4 class="card-header-title">Basic info</h4>
              </div>
              <?= $getBCAPI->getUpdate()?>
              <!-- Body -->
              <div class="card-body">
              <div class="list-group list-group-flush list-group-no-gutters">
                    <div class="list-group-item">
                      <div class="d-flex">
                        <div class="flex-grow-1 ms-3">
                          <div class="row align-items-center">
                            <div class="col">
                              <h6 class="mb-1">Status</h6>
                            </div>
                            <div class="col-auto">
                            <?= $getBCAPI->getOnlineSatatus()?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="list-group list-group-flush list-group-no-gutters">
                    <div class="list-group-item">
                      <div class="d-flex">
                        <div class="flex-grow-1 ms-3">
                          <div class="row align-items-center">
                            <div class="col">
                              <h6 class="mb-1">Last server</h6>
                            </div>
                            <div class="col-auto">
                              <p><?= $getBCAPI->getLastServer()?></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <hr>
                  <div class="list-group list-group-flush list-group-no-gutters">
                    <div class="list-group-item">
                      <div class="d-flex">
                        <div class="flex-grow-1 ms-3">
                          <div class="row align-items-center">
                            <div class="col">
                              <h6 class="mb-1">Last login</h6>
                            </div>
                            <div class="col-auto">
                              <p><?= $getBCAPI->getLastLogin()?></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
        <!-- End Col -->
      </div>
      <!-- End Row -->
    </div>
    <!-- End Content -->
  </main>
  <footer class="bg-light">
    <? require_once("../core/html/footer.php")?>
  </footer>
  <a class="js-go-to go-to position-fixed" href="javascript:;" style="visibility: hidden;"
     data-hs-go-to-options='{
       "offsetTop": 700,
       "position": {
         "init": {
           "right": "2rem"
         },
         "show": {
           "bottom": "2rem"
         },
         "hide": {
           "bottom": "-2rem"
         }
       }
     }'>
    <i class="bi-chevron-up"></i>
  </a>
  <!-- ========== END SECONDARY CONTENTS ========== -->


  <!-- JS Implementing Plugins -->
  <script src="../assets/js/vendor.min.js"></script>

  <!-- JS Front -->
  <script src="../assets/js/theme.min.js"></script>
  <script>
    (function() {
      // INITIALIZATION OF HEADER
      // =======================================================
      new HSHeader('#header').init()


      // INITIALIZATION OF MEGA MENU
      // =======================================================
      new HSMegaMenu('.js-mega-menu', {
          desktop: {
            position: 'left'
          }
        })


      // INITIALIZATION OF SHOW ANIMATIONS
      // =======================================================
      new HSShowAnimation('.js-animation-link')


      // INITIALIZATION OF BOOTSTRAP VALIDATION
      // =======================================================
      HSBsValidation.init('.js-validate', {
        onSubmit: data => {
          data.event.preventDefault()
          alert('Submited')
        }
      })


      // INITIALIZATION OF BOOTSTRAP DROPDOWN
      // =======================================================
      HSBsDropdown.init()


      // INITIALIZATION OF GO TO
      // =======================================================
      new HSGoTo('.js-go-to')


      // INITIALIZATION OF FILE ATTACH
      // =======================================================
      new HSFileAttach('.js-file-attach')


      // INITIALIZATION OF ADD FIELD
      // =======================================================
      new HSAddField('.js-add-field', {
        addedField: el => {
          el.querySelectorAll('.js-select-dynamic').forEach(item => {
            HSCore.components.HSTomSelect.init(item)
          })

          HSCore.components.HSMask.init('.js-input-mask-dynamic')
        }
      })


      // INITIALIZATION OF INPUT MASK
      // =======================================================
      HSCore.components.HSMask.init('.js-input-mask')


      // INITIALIZATION OF QUILLJS EDITOR
      // =======================================================
      HSCore.components.HSQuill.init('.js-quill')

      
      // INITIALIZATION OF SELECT
      // =======================================================
      HSCore.components.HSTomSelect.init('.js-select', {
        render: {
          'option': function(data, escape) {
            return data.optionTemplate || `<div>${data.text}</div>>`
          },
          'item': function(data, escape) {
            return data.optionTemplate || `<div>${data.text}</div>>`
          }
        }
      })
    })()
  </script>
</body>
</html>

