<?php
session_start();

$ourData = file_get_contents("core/lang/en_EN.json" );
$getLang = json_decode($ourData, true);

if (is_dir("install")){
    $file = 'core/config.php';
    if(!is_file($file)){
        $contents = '';
        file_put_contents($file, $contents);
    }
    header("Location: https://".$_SERVER['HTTP_HOST']."/install/db");
}

?>

<!DOCTYPE html>
<html lang="en" dir="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $getLang['main']['ServerName']?> - <?= $getLang['home']['title']?> </title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="../css2-1.css?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/vendor.min.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/vendor/aos/dist/aos.css">
    <link rel="stylesheet" href="assets/css/theme.min.css?v=1.0">
    <link rel="stylesheet" href="assets/vendor/icon-set/style.css">
</head>
<body>
<header id="header" class="navbar navbar-expand-lg navbar-end navbar-absolute-top navbar-light navbar-show-hide"
        data-hs-header-options='{
            "fixMoment": 1000,
            "fixEffect": "slide"
          }'>
          <? require_once("core/html/header.php")?>
</header>
<main id="content" role="main">
    <div class="d-lg-flex position-relative">
        <div class="container d-lg-flex align-items-lg-center content-space-t-3 content-space-lg-0 min-vh-lg-100">
            <div class="w-100">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="mb-5">
                            <h1 class="display-4 mb-3">
                                The adventure starts
                                <span class="text-primary text-highlight-warning">
                              here.
                              </span>
                            </h1>
                            <p class="lead"><?= $getLang['home']['text_1']?></p>
                        </div>
                        <div class="d-grid d-sm-flex gap-3">
                            <a class="btn btn-primary btn-transition px-6" href="login"><?= $getLang['home']['text_4']?></a>
                            <a class="btn btn-link" href="store"><?= $getLang['home']['text_5']?> <i class="bi-chevron-right small ms-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-xl-6 d-none d-lg-block position-absolute top-0 end-0 pe-0" style="margin-top: 4.45rem;">
                <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewbox="0 0 1137.5 979.2">
                    <path fill="#F9FBFF" d="M565.5,957.4c81.1-7.4,155.5-49.3,202.4-115.7C840,739.8,857,570,510.7,348.3C-35.5-1.5-4.2,340.3,2.7,389
                        c0.7,4.7,1.2,9.5,1.7,14.2l29.3,321c14,154.2,150.6,267.8,304.9,253.8L565.5,957.4z"></path>
                    <defs>
                        <path id="mainHeroSVG1" d="M1137.5,0H450.4l-278,279.7C22.4,430.6,24.3,675,176.8,823.5l0,0C316.9,960,537.7,968.7,688.2,843.6l449.3-373.4V0z"></path>
                    </defs>
                    <clippath id="mainHeroSVG2">
                        <use xlink:href="#mainHeroSVG1"></use>
                    </clippath>
                    <g transform="matrix(1 0 0 1 0 0)" clip-path="url(#mainHeroSVG2)">
                        <image width="750" height="750" xlink:href="./assets/img/home/home.png" transform="matrix(1.4462 0 0 1.4448 52.8755 0)"></image>
                    </g>
                </svg>
            </div>
        </div>

    </div>
</main>
<div class="container">
    <div class="w-md-75 w-lg-50 text-center mx-md-auto mb-5 mb-md-9">
        <span class="text-cap"><?= $getLang['home']['text_2']?></span>
        <h2><?= $getLang['home']['text_3']?></h2>
    </div>
    <div class="row mb-5 mb-md-9">
        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7">
            <div class="d-flex align-items-center mb-2">
                <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M15 19.5229C15 20.265 15.9624 20.5564 16.374 19.9389L22.2227 11.166C22.5549 10.6676 22.1976 10 21.5986 10H17V4.47708C17 3.73503 16.0376 3.44363 15.626 4.06106L9.77735 12.834C9.44507 13.3324 9.80237 14 10.4014 14H15V19.5229Z" fill="#035A4B"/>
                <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M3 6.5C3 5.67157 3.67157 5 4.5 5H9.5C10.3284 5 11 5.67157 11 6.5C11 7.32843 10.3284 8 9.5 8H4.5C3.67157 8 3 7.32843 3 6.5ZM3 18.5C3 17.6716 3.67157 17 4.5 17H9.5C10.3284 17 11 17.6716 11 18.5C11 19.3284 10.3284 20 9.5 20H4.5C3.67157 20 3 19.3284 3 18.5ZM2.5 11C1.67157 11 1 11.6716 1 12.5C1 13.3284 1.67157 14 2.5 14H6.5C7.32843 14 8 13.3284 8 12.5C8 11.6716 7.32843 11 6.5 11H2.5Z" fill="#035A4B"/>
                </svg>
              </span>
                </div>

                <div class="flex-grow-1 ms-3">
                    <h4 class="mb-0"><?= $getLang['home']['f']['text_1']?></h4>
                </div>
            </div>
            <p><?= $getLang['home']['f_dec']['f_dec_1']?></p>
        </div>
        <div class="col-sm-6 col-md-4 mb-3 mb-sm-7">
            <div class="d-flex align-items-center mb-2">
                <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.302 11.35L12.002 20.55H21.202C21.802 20.55 22.202 19.85 21.902 19.35L17.302 11.35Z" fill="#035A4B"/>
                <path opacity="0.3" d="M12.002 20.55H2.802C2.202 20.55 1.80202 19.85 2.10202 19.35L6.70203 11.45L12.002 20.55ZM11.302 3.45L6.70203 11.35H17.302L12.702 3.45C12.402 2.85 11.602 2.85 11.302 3.45Z" fill="#035A4B"/>
                </svg>
              </span>
                </div>

                <div class="flex-grow-1 ms-3">
                    <h4 class="mb-0"><?= $getLang['home']['f']['text_2']?></h4>
                </div>
            </div>
            <p><?= $getLang['home']['f_dec']['f_dec_2']?></p>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="d-flex align-items-center mb-2">
                <div class="flex-shrink-0">
              <span class="svg-icon svg-icon-sm text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path opacity="0.3" d="M5 8.04999L11.8 11.95V19.85L5 15.85V8.04999Z" fill="#035A4B"/>
                <path d="M20.1 6.65L12.3 2.15C12 1.95 11.6 1.95 11.3 2.15L3.5 6.65C3.2 6.85 3 7.15 3 7.45V16.45C3 16.75 3.2 17.15 3.5 17.25L11.3 21.75C11.5 21.85 11.6 21.85 11.8 21.85C12 21.85 12.1 21.85 12.3 21.75L20.1 17.25C20.4 17.05 20.6 16.75 20.6 16.45V7.45C20.6 7.15 20.4 6.75 20.1 6.65ZM5 15.85V7.95L11.8 4.05L18.6 7.95L11.8 11.95V19.85L5 15.85Z" fill="#035A4B"/>
                </svg>
              </span>
                </div>
                <div class="flex-grow-1 ms-3">
                    <h4 class="mb-0"><?= $getLang['home']['f']['text_3']?></h4>
                </div>
            </div>
            <p><?= $getLang['home']['f_dec']['f_dec_3']?></p>
        </div>
    </div>
</div>
<footer class="bg-light">
    <? require_once("core/html/footer.php")?>
</footer>
<script src="assets/js/vendor.min.js"></script>
<script src="assets/vendor/aos/dist/aos.js"></script>
<script src="assets/js/theme.min.js"></script>
<script>
    (function() {
        // INITIALIZATION OF HEADER
        // =======================================================
        new HSHeader('#header').init()


        // INITIALIZATION OF MEGA MENU
        // =======================================================
        new HSMegaMenu('.js-mega-menu', {
            desktop: {
                position: 'left'
            }
        })


        // INITIALIZATION OF SHOW ANIMATIONS
        // =======================================================
        new HSShowAnimation('.js-animation-link')


        // INITIALIZATION OF BOOTSTRAP VALIDATION
        // =======================================================
        HSBsValidation.init('.js-validate', {
            onSubmit: data => {
                data.event.preventDefault()
                alert('Submited')
            }
        })


        // INITIALIZATION OF BOOTSTRAP DROPDOWN
        // =======================================================
        HSBsDropdown.init()


        // INITIALIZATION OF GO TO
        // =======================================================
        new HSGoTo('.js-go-to')


        // INITIALIZATION OF AOS
        // =======================================================
        AOS.init({
            duration: 650,
            once: true
        });


        // INITIALIZATION OF TEXT ANIMATION (TYPING)
        // =======================================================
        HSCore.components.HSTyped.init('.js-typedjs')


        // INITIALIZATION OF SWIPER
        // =======================================================
        var sliderThumbs = new Swiper('.js-swiper-thumbs', {
            watchSlidesVisibility: true,
            watchSlidesProgress: true,
            history: false,
            breakpoints: {
                480: {
                    slidesPerView: 2,
                    spaceBetween: 15,
                },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 15,
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 15,
                },
            },
            on: {
                'afterInit': function (swiper) {
                    swiper.el.querySelectorAll('.js-swiper-pagination-progress-body-helper')
                        .forEach($progress => $progress.style.transitionDuration = `${swiper.params.autoplay.delay}ms`)
                }
            }
        });

        var sliderMain = new Swiper('.js-swiper-main', {
            effect: 'fade',
            autoplay: true,
            loop: true,
            thumbs: {
                swiper: sliderThumbs
            }
        })
    })()
</script>
</body>
</html>
