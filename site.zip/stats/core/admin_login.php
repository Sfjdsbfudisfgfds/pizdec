<?php
session_start();

$ourData = file_get_contents("lang/en_EN.json" );
$getLang = json_decode($ourData, true);
include_once('config.php');
$connect = mysqli_connect($host, $user, $pass, $db);

if (!empty($_POST['username'] && $_POST['password'])){

    if($_POST['username'] && $_POST['password']){

        $user = $_POST['username'];
        $pass = $_POST['password'];
        $md5Hash = md5($_POST['password']);
        $result = mysqli_query($connect, "SELECT * FROM bcapi_web_admin WHERE username='$user' AND password='$md5Hash'");
        $row = mysqli_fetch_array($result);

        if($row){
            sleep(5);
            $response = [
                "status" => true,
                "player" => $row['username']
            ];

            echo json_encode($response);

            $session_start = $row['username'];
            $_SESSION['admin'] = $session_start;


        } else {

            $response = [
                "status" => false,
                "msg" => $getLang['admin']['error_passANDuser']
            ];

            echo json_encode($response);
        }

    }

} else {
    $response = [
        "status" => false,
        "msg" => $getLang['admin']['empty_input']
    ];

    echo json_encode($response);
}
?>