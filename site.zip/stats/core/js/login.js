$('.login-btn').click(function (e) {
    e.preventDefault();
    let api = $('input[name="api"]').val()
    $.ajax({
        url: 'core/login.php',
        type: 'POST',
        dataType: 'json',
        data: {
            api: api,
        },
        beforeSend:function(){
            $('.loader').show();
            $('.ramove-btn').hide();
        },
        success (data) {
            if (data.status) {
                window.location.replace("http://stackoverflow.com");
                location.href = 'newPage.html';
                window.location.href = 'http://www.example.com'
                $('.success-id').show();
                $('.loader').hide();
            } else {
                $('.msg').removeClass('display-none').text(data.msg);
                $('.loader').hide();
                $('.error-id').show();
                $('.ramove-btn').show();
            }
        }
    });
});