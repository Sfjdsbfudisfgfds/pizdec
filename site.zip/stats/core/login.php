<?php
session_start();

$ourData = file_get_contents("lang/en_EN.json" );
$getLang = json_decode($ourData, true);
include "config.php";
$connect = mysqli_connect($host, $user, $pass, $db);
$date = date("Y-m-d H:i:s");
if (isset($_POST['api'])){
    header('Content-Type: application/json; charset=utf-8');
    $api = $_POST['api'];

    if (!empty($api)){
        $apiJson = json_decode(file_get_contents('https://'.$_SERVER['HTTP_HOST'].'/core/api/api.php?api='.$api), true);


        if($apiJson['status'] == true){
            sleep(5);

            $response = [
                "status" => true,
                "player" => $apiJson['owner']
            ];
            echo json_encode($response);

            $getPlayer = $apiJson['owner'];


            $query = mysqli_query($connect, "INSERT IGNORE INTO bcapi_web_user (username, api_key, email, balance, firs_join, last_login, banned) VALUES('$getPlayer', '$api', NULL, 0, '$date', NULL, '0')");
            $query = mysqli_query($connect, "UPDATE bcapi_web_user SET last_login='$date', api_key='$api' WHERE username='$getPlayer'");

            //User session
            $query = mysqli_query($connect, "INSERT IGNORE INTO bcapi_web_userSession (username, ip_login, date_login) VALUES('$getPlayer', NULL, '$date')");


            $session_start = $apiJson['owner'];
            $_SESSION['player'] = $session_start;
            

        } else {
            sleep(3);
            $response = [
              "status" => false,
              "msg" => $getLang['login']['error_API']
            ];

            echo json_encode($response);
        }

    } else {
        $response = [
            "status" => false,
            "msg" => $getLang['login']['empty_input']
        ];

        echo json_encode($response);
    }
}



//if(!empty($_POST['username'] or $_POST['password']))
//
//    $pass = md5($_POST['password']);
//$result = mysqli_query($connect, "SELECT * FROM bungeecordapi_web_admin WHERE  password='$pass'");
//$row = mysqli_fetch_array($result);
//
//if($row['password'] == $pass){
//    echo "ok";
//} else {
//    echo "no";
//}
?>