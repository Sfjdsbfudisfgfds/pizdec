<?php
include_once('../config.php');
$connect = mysqli_connect($host, $user, $pass, $db);


if(isset($_GET['api'])){
    $api = $_GET['api'];
    header('Content-Type: application/json; charset=utf-8');
    if(!empty($api)){
        
        $result = mysqli_query($connect, "SELECT * FROM bungeecordapi WHERE api='$api'");
        $row = mysqli_fetch_array($result);
        $player_api = $row['api'];
        $player_name = $row['username'];
        $request_limit = $row['request_limit'];

        if($player_api == $api){            
            if($request_limit == 0){

                $response = [

                    "status" => false,
                    "owner" => $player_name,
                    "msg" => 'The request limit has been reached. Update your API key.'
        
                ];
        
                echo json_encode($response);
            } else {                
                $result = mysqli_query($connect, "UPDATE bungeecordapi SET request_limit = request_limit - 1 WHERE username = '".$player_name."'");
                $response = [

                    "status" => true,
                    "owner" => $player_name,
                    "api" => [
                        "request limit type" => "Per month",
                        "requests left" => $request_limit,
                        "requests max" => 600
                    ]
        
                ];
        
                echo json_encode($response);
            }

        } else {
            $response = [

                "status" => false,
                "msg" => "Invalid API key"
    
            ];
    
            echo json_encode($response);
        }

    } else {
        
        $response = [

            "status" => false,
            "msg" => "Enter the API token"

        ];

        echo json_encode($response);

    }

}
