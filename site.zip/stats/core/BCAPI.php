<?php

namespace hengab;

class BCAPI
{
    private $playerSession;

    public function __construct($playerSession)
    {
        require("config.php");
        $connect = mysqli_connect($host, $user, $pass, $db);
        $this->player = $playerSession;
        $PSN = $playerSession;
        $query = mysqli_query($connect,"SELECT * FROM bcapi_web_user WHERE username='$PSN'");
        $row = mysqli_fetch_assoc($query);
        $playerStats = mysqli_query($connect, "SELECT * FROM `bungeecordapi` WHERE username='$PSN'");
        $playerStats_get = mysqli_fetch_assoc($playerStats);

        $this->PLAYERNAME = $row['username'];
        $this->lastServer = $playerStats_get['last_server'];
        $this->lastLogin = $playerStats_get['last_login'];
        $this->onlineSatatus = $playerStats_get['online_status'];
        $this->balance = $row['balance'];

    }

    public function getName()
    {
        return $this->PLAYERNAME;

    }

    public function getLastServer()
    {
        return $this->lastServer;

    }

    public function getLastLogin()
    {
        return $this->lastLogin;

    }

    public function getOnlineSatatus()
    {
        if($this->onlineSatatus == '1'){
            echo '<span class="badge bg-success">Online</span>';
        } else {
            echo '<span class="badge bg-danger">Offline</span>';
        }

    }

    public function getCoins()
    {
        if ($this->balance == NULL){
            echo "no date";
        } else {
            $nombre_format_francais = number_format($this->balance, 2, ',', ' ');
            echo $nombre_format_francais;
        }
    }

    public function getUpdate(){

        $version = "2.0";
        $updateCehck = json_decode(file_get_contents('https://ovlu.net/core/updateCheck.php'), true);
        $newVer = $updateCehck['ver'];
        if($newVer == $version){
        } else {
            echo '
            
            <div class="alert alert-soft-danger text-center card-alert" role="alert">
                New update released '.$newVer.'. Your version: '.$version.'. <a class="alert-link" href="https://download.ovlu.net/ovlu-'.$newVer.'.zip  " target="_blank">Download new updaten</a>
            </div>
            
            ';
        }

    }


}
?>
