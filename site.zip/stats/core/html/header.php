<div class="container">
      <nav class="js-mega-menu navbar-nav-wrap">
        <a class="navbar-brand" href="../">
          <img class="navbar-brand-logo" src="../../assets/ovlu-logo/logo.png">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-default">
            <i class="bi-list"></i>
          </span>
          <span class="navbar-toggler-toggled">
            <i class="bi-x"></i>
          </span>
        </button>
        <div class="collapse navbar-collapse">
          <ul class="navbar-nav">
            <a class="hs-mega-menu-invoker nav-link"  href="/store">Store</a>
            <a class="hs-mega-menu-invoker nav-link " href="/bans">Ban list</a>
            <a class="hs-mega-menu-invoker nav-link " href="/forum">Forum</a>
        
            <li class="nav-item">
                            <?php
                                if($_SESSION['player']){
                                    ?>
                                        <div class="avatar">
                                            <a href="account"><img class="avatar-img" src="https://minotar.net/helm/<?= $_SESSION['player']?>" alt="Image Description"></a>
                                        </div>
                                    <?
                                }  else {
                                    ?>
                                        <a class="btn btn-primary btn-transition" href="login"><?= $getLang['login']['form_Button']?></a>
                                    <?
                                }                      
                            ?>
            </li>
          </ul>
        </div>
      </nav>
    </div>