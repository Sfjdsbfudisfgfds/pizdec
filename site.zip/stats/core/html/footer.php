<br>
  <br>
  <br>
    <div class="container pb-1 pb-lg-7">
      <div class="w-md-85 text-lg-center mx-lg-auto">
        <p class="text-muted small">© <? echo date("Y")?> <?= $getLang['main']['ServerName']?>. <?= $getLang['footer']['footerTitle']?></p>
        <p class="text-muted small"><?= $getLang['footer']['footer_description']?></p>
      </div>
    </div>