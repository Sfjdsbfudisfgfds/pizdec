<?php
session_start();

if ($_SESSION['player']){
    session_unset();
    header("Location: ../../");
} else {
    header("Location: ../../");
}

