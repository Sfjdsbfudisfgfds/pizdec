<?php
session_start();
if($_SESSION['admin']){
    header("Location: panel");
} else {
    header("Location: login");
}