<?php
session_start();

//use hengab\dash;
//require_once("core/dashboard.php");
//$get = new dash;
//
//
//$ourData = file_get_contents("../core/lang/en_EN.json" );
//$getLang = json_decode($ourData, true);

if (!$_SESSION['admin']){
    header("Location: login");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OVLU - Admin panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./assets/css/vendor.min.css">
    <link rel="stylesheet" href="./assets/vendor/icon-set/style.css">
    <link rel="stylesheet" href="./assets/css/theme.min.css?v=1.0">
</head>

<body>
<main class="main">
    <div class="container">
        <a class="position-absolute top-0 mt-3 left-0 right-0" href="https://ovlu.net" target="_blank">
            <img class="avatar-4by3 avatar-centered" src="assets/logo-ovlu/ovlu-logo.png" alt="Image Description">
        </a>

        <div class="footer-height-offset d-flex justify-content-center align-items-center flex-column">
            <div class="row align-items-sm-center w-100">
                <div class="col-sm-6">
                    <div class="text-center text-sm-right mr-sm-4 mb-5 mb-sm-0">
                        <img class="w-60 w-sm-100 mx-auto" src="assets/logo-ovlu/home.png" alt="Image Description" style="max-width: 15rem;">
                    </div>
                </div>

                <div class="col-sm-6 col-md-4 text-center text-sm-left">
                    <h1 class="display-1 mb-0">OVLU 3.0.</h1>
                    <p class="lead">Our website is under construction. We'll be here soon with our new awesome site.</p>
                    <a class="btn btn-primary" href="core/logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </div>

</main>
<script src="assets/js/theme.min.js"></script>
<script>
    if (/MSIE \d|Trident.*rv:/.test(navigator.userAgent)) document.write('<script src="./assets/vendor/babel-polyfill/polyfill.min.js"><\/script>');
</script>
</body>
</html>