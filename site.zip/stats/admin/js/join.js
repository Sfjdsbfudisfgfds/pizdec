$('.login-btn').click(function (e) {
    e.preventDefault();
    let htopid = $('input[name="htopid"]').val()
    $.ajax({
        url: 'htopid.php',
        type: 'POST',
        dataType: 'json',
        data: {
            htopid: htopid,
        },
        success (data) {
            if (data.status) {
                document.location.href = 'https://hypixeltop.pro/';
            } else {
                $('.msg').removeClass('d-md-none').text(data.msg);
            }
        }
    });
});
