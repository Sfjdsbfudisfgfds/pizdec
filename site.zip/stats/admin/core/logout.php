<?php
session_start();
if ($_SESSION['admin']){
    session_unset();
    header("Location: ../../");
} else {
    header("Location: ../../");
}

