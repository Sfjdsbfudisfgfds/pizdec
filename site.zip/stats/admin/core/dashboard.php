<?php

namespace hengab;

class dash
{

 //soon

}
