<?php
session_start();
$ourData = file_get_contents("../core/lang/en_EN.json" );
$getLang = json_decode($ourData, true);

if ($_SESSION['admin']){
    header("Location: panel");
}
?>

<!DOCTYPE html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $getLang['main']['ServerName']?> - <?= $getLang['admin']['form_description']?></title>
    <link rel="shortcut icon" href="./favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/vendor.min.css">
    <link rel="stylesheet" href="assets/vendor/icon-set/style.css">
    <link rel="stylesheet" href="assets/css/theme.min.css?v=1.0">
  </head>
  <body class="d-flex align-items-center min-h-100">
    <main id="content" role="main" class="main pt-0">
      <div class="container-fluid px-3">
        <div class="row">
        <div class="position-absolute top-0 left-0 right-0 mt-3 mx-3">
          <div class="col-lg-12 d-flex justify-content-center align-items-center min-vh-lg-100">
            <div class="w-100 pt-10 pt-lg-7 pb-7" style="max-width: 25rem;">
              <form>
                <div class="text-center mb-5">
                  <h1 class="display-4"><?= $getLang['main']['ServerName']?></h1>
                  <p><?= $getLang['admin']['form_description']?></p>
                </div>
                <div class="js-form-message form-group">
                    <input type="text" class="form-control form-control-lg" name="username" placeholder="<?= $getLang['admin']['form_inputPlaceholder_user']?>" required data-msg="Please enter the API key." tabindex="1">
                    <br>
                    <input type="password" class="form-control form-control-lg" name="password" placeholder="<?= $getLang['admin']['form_inputPlaceholder_pass']?>" required data-msg="Please enter the API key." tabindex="1">
                </div>
                <button type="submit" class="btn btn-block btn-primary login-btn ramove-btn"><?= $getLang['admin']['form_Button']?></button>
                <button type="submit" class="btn btn-block btn-primary login-btn loader" style="display: none;" disabled><span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></button>
              </form>
              <div class="error-id" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
                <div class="alert alert-danger alert-dismissible fade show msg" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="tio-clear tio-lg"></i>
                  </button>
                </div>
              </div>
              <div class="success-id" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
                <div class="alert alert-success alert-dismissible fade show" role="alert"><?= $getLang['admin']['LoginSuccess']?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="tio-clear tio-lg"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <style>
    .error-id {
      display: none;
    }
    .success-id {
      display: none;
    }
    </style>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script type="text/javascript">
    $('.login-btn').click(function (e) {

        e.preventDefault();

        let username = $('input[name="username"]').val()
        let password = $('input[name="password"]').val()

        $.ajax({

            url: '../core/admin_login.php',

            type: 'POST',

            dataType: 'json',

            data: {

                username: username,
                password: password

            },
            beforeSend:function(){
              $('.loader').show();
              $('.ramove-btn').hide();
            },
            success (data) {

              if (data.status) {

                  setTimeout(function(){
                    window.location.href = 'panel';
                  }, 2 * 1000);
                  $('.success-id').show();
                  $('.loader').hide();
                  $('.ramove-btn').show();

              } else {

                  $('.msg').removeClass('display-none').text(data.msg);
                  $('.loader').hide();
                  $('.error-id').show();
                  $('.ramove-btn').show();

              }

            }

        });

    });
    </script>
    <script>
      var _paq = window._paq = window._paq || [];
      /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
      _paq.push(['trackPageView']);
      _paq.push(['enableLinkTracking']);
      (function() {
        var u="//analytics.hypixeltop.pro/";
        _paq.push(['setTrackerUrl', u+'matomo.php']);
        _paq.push(['setSiteId', '1']);
        var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
        g.async=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
      })();
    </script>


  </body>

</html>


