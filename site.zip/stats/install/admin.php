
<!DOCTYPE html>
<html lang="en" dir="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OVLU - Installation: Second step</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/vendor.min.css">
    <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/theme.min.css?v=1.0">
</head>

<body>

<main>
    <div class="container content-space-3 content-space-t-lg-4 content-space-b-lg-3">
        <div class="flex-grow-1 mx-auto" style="max-width: 28rem;">
            <div class="text-center mb-5 mb-md-7">
                <h4 class="step-title">Second step</h4>
                <p class="step-text">Now it remains to create an administrator account.</p>
            </div>

            <div class="ramove">
                <form method="post">
                    <div class="mb-4">
                        <input type="text" class="form-control form-control-lg" name="username" placeholder="Username" required>
                    </div>
                    <div class="mb-4">
                        <input type="text" class="form-control form-control-lg" name="password" placeholder="Password" required>
                    </div>
                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-primary btn-lg send-btn">Finish</button>
                    </div>
                </form>
            </div>
            <div class="text-center loader text-primary" style="display: none;">
                <div class="spinner-border" style="width: 3rem; height: 3rem;" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script type="text/javascript">


    $('.send-btn').click(function (e) {
        e.preventDefault();
        let username = $('input[name="username"]').val()
        let password = $('input[name="password"]').val()
        $.ajax({
            url: 'createAdmin.php',
            type: 'POST',
            dataType: 'json',
            data: {
                username: username,
                password: password,
            },
            beforeSend:function(){
                $('.loader').show();
                $('.ramove').hide();
            },
            success (data) {
                if (data.status) {
                    window.location.href = 'delDir.php';
                    $('.loader').hide();
                    $('.ramove').show();
                } else {
                    alert(data.msg);
                    $('.ramove').show();
                    $('.loader').hide();
                }
            }
        });
    });
</script>
</body>
</html>
