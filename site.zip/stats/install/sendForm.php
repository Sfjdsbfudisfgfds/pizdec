<?php

if (isset($_POST['host'], $_POST['username'], $_POST['password'], $_POST['database'])){
    header('Content-Type: application/json; charset=utf-8');
    $mysql_host = $_POST['host'];
    $mysql_username = $_POST['username'];
    $mysql_password = $_POST['password'];
    $mysql_database = $_POST['database'];

    if (!empty($mysql_host) and !empty($mysql_username) and !empty($mysql_password) and !empty($mysql_database)){

        $conn = mysqli_connect($mysql_host, $mysql_username, $mysql_password, $mysql_database);


        if (!$conn) {
            sleep(3);
            $response = [
                "status" => false,
                "msg" => "MySQL database connection error"
            ];

            echo json_encode($response);
        } else {
            sleep(6);
            $response = [
                "status" => true,
                "msg" => "ok"
            ];

            echo json_encode($response);

            $file = '../core/config.php';
            if(is_file($file)){
                $config = '
<?php

$host = "'.$mysql_host.'";
$user = "'.$mysql_username.'";
$db = "'.$mysql_database.'";
$pass = "'.$mysql_password.'";

?>
                ';
                file_put_contents($file, $config);

                $connect = mysqli_connect($mysql_host, $mysql_username, $mysql_password, $mysql_database);
                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_main (maintenance_status VARCHAR(100), smt_status VARCHAR(100), ticket_status VARCHAR(100), store_status VARCHAR(100), luckperms_status VARCHAR(100), litebans_status VARCHAR(100), cyberlevels_status VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_main (maintenance_status, smt_status, ticket_status, store_status, luckperms_status, litebans_status, cyberlevels_status) VALUES('0', '0', '0', '0', '0', '0', '0')");

                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_links (vk_link VARCHAR(100), twitch_link VARCHAR(100), discord_link VARCHAR(100), twitter_link VARCHAR(100), youtube_link VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_links (vk_link, twitch_link, discord_link, twitter_link, youtube_link) VALUES(NULL, NULL, NULL, NULL, NULL)");

                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_product (product_name VARCHAR(100), product_des VARCHAR(100), price INT(100), rcon_send VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_product (product_name, product_des, price, rcon_send) VALUES(NULL, NULL, NULL, NULL)");

                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_addons (luckperms VARCHAR(100), litebans VARCHAR(100), cyberlevels VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_addons (luckperms, litebans, cyberlevels) VALUES('0', '0', '0')");

                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_ticketcategory (ticket_name VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_ticketcategory (ticket_name) VALUES(NULL)");

                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_ticketrequests (username VARCHAR(100), ticket_id VARCHAR(100), ticket_name VARCHAR(100), ticket_link VARCHAR(100), ticket_ages VARCHAR(100), ticket_aboutme VARCHAR(100), ticket_status VARCHAR(100), ticket_created VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_ticketrequests (username, ticket_id, ticket_name, ticket_link, ticket_ages, ticket_aboutme, ticket_status, ticket_created) VALUES(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)");
                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS `bcapi_web_payments` ( `payment_id` int(11) NOT NULL AUTO_INCREMENT, `item_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL, `txn_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL, `payment_gross` float(10,2) NOT NULL, `currency_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL, `payment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL, PRIMARY KEY (`payment_id`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;");

                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_smt (smt_host VARCHAR(100), smt_username VARCHAR(100), smt_password VARCHAR(100), smt_port VARCHAR(100))");
                $query = mysqli_query($connect, "INSERT INTO bcapi_web_smt (smt_host, smt_username, smt_password, smt_port) VALUES(NULL, NULL, NULL, NULL)");
                $query = mysqli_query($connect, "CREATE TABLE IF NOT EXISTS bcapi_web_admin (username VARCHAR(100) UNIQUE, password VARCHAR(100))");
                $query = mysqli_query($connect, " CREATE TABLE IF NOT EXISTS bcapi_web_userSession (username VARCHAR(100), ip_login VARCHAR(100), date_login VARCHAR(100)) ");
                $query = mysqli_query($connect, " CREATE TABLE IF NOT EXISTS bcapi_web_user (username VARCHAR(100) UNIQUE, api_key VARCHAR(100), email VARCHAR(100), balance int(100), firs_join VARCHAR(100), last_login VARCHAR(100), banned VARCHAR(100)) ");
            }
        }
    } else {
        $response = [
            "status" => false,
            "msg" => "Enter date"
        ];

        echo json_encode($response);
    }
}